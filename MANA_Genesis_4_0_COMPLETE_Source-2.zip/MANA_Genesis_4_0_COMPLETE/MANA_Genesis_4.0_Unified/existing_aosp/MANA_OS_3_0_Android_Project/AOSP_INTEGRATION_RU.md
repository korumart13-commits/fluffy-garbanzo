# MANA OS 3.0 — AOSP integration

Добавлены шаблоны Soong, product makefiles, RRO skeleton, пустой privileged
permission allowlist, рекомендации SELinux и план безопасной интеграции SystemUI.

Это не готовая прошивка. Не заданы AOSP branch, device tree, kernel, vendor/HAL,
partition layout, AVB keys и OTA signing. Штатный AOSP SystemUI сохраняется;
companion-модуль не заменяет его. См. `aosp/README/BUILD_RU.md`.
