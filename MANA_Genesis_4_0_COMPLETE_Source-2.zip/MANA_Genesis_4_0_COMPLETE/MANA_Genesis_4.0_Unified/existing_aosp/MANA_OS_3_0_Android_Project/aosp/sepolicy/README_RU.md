# MANA SELinux policy

В стартовом пакете нет allow-правил и permissive-доменов. SELinux остаётся Enforcing.
Добавляйте минимальные device/product-specific правила только после определения
процесса, типа данных и IPC-интерфейса. Не генерируйте политику автоматически из
`audit2allow`, не добавляйте широкие allow, не обходите neverallow и не отключайте
SELinux. Проверяйте AVC, CTS и VTS. Не предоставляйте MANA доступ к keystore,
gatekeeper, TEE или vendor-компонентам без отдельного security review.
