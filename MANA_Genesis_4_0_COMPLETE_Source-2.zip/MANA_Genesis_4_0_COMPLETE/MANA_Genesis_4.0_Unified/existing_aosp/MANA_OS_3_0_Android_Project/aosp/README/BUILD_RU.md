# Сборка AOSP-интеграции MANA OS 3.0

Это стартовые Soong-шаблоны, не готовый универсальный ROM. Свойства Android.bp,
Kotlin toolchain и overlay policy зависят от конкретной ветки AOSP.

## Размещение

Перенесите папку `aosp/` в `vendor/mana/` в дереве AOSP. Перенесите или
синхронизируйте Android Studio исходники в ожидаемые пути, затем исправьте
относительные пути `srcs`, `manifest` и `resource_dirs` в `vendor/mana/Android.bp`.

В device/product makefile конкретного устройства добавьте:

`$(call inherit-product, vendor/mana/product/mana_product.mk)`

## Сборка

Из корня AOSP:

1. `source build/envsetup.sh`
2. `lunch <реальный-device-target>-<variant>`
3. `m ManaCore ManaLauncher ManaSettings ManaCompanion ManaSystemUiCompanion`
4. `m ManaFrameworkOverlay`
5. `m`

Не угадывайте lunch target: используйте только target из device tree конкретной модели.

## Проверки перед прошивкой

- успешная полная сборка;
- проверка размещения APK и overlay;
- минимальный reviewed privapp allowlist;
- SELinux Enforcing и анализ AVC;
- CTS/VTS и smoke tests на целевом устройстве;
- AVB signing, vbmeta chain, rollback index и OTA metadata;
- проверенный путь восстановления штатного образа.

Не прошивайте пакет, если device codename, разделы, AVB chain или подписи не совпадают.
