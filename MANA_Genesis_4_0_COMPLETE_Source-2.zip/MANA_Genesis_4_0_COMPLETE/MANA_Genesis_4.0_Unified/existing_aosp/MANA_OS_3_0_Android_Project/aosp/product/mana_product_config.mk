# Optional branding property only; do not alter boot/security properties.
PRODUCT_PRODUCT_PROPERTIES += persist.sys.mana.branding=1
# Never override ro.boot.verifiedbootstate, ro.boot.flash.locked,
# SELinux mode, vbmeta, or verified boot properties here.
