# Include from a device/product makefile after validating module paths.
PRODUCT_PACKAGES += \
    ManaLauncher \
    ManaSettings \
    ManaCompanion \
    ManaSystemUiCompanion \
    ManaFrameworkOverlay
# Keep the existing AOSP SystemUI; this package is a companion, not a replacement.
