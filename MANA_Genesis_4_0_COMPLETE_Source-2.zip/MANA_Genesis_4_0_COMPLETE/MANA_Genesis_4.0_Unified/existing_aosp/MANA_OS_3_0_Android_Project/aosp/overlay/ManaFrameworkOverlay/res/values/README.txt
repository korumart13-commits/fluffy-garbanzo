No overrides are enabled. Add only resource names confirmed in the exact AOSP branch,
declared overlayable, and allowed by the product overlay policy. Never overlay security,
lock-screen, permission, verified-boot, or SELinux behavior.
