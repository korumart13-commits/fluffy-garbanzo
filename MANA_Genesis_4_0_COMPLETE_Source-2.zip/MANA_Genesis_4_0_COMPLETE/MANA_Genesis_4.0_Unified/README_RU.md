# MANA Genesis 4.0 — Unified Source Package

Содержимое:
- `MANA_Genesis_4_0_AllInOne.kt` — один консолидированный Kotlin-файл с общей моделью и интерфейсами модулей.
- `existing_aosp/MANA_OS_3_0_Android_Project/` — исходный Android-проект MANA 3.0, обновлённые метаданные версии и добавленный единый core.
- `previous_adaptive_intelligence/` — ранее созданный модуль адаптивного обучения/поиска.
- `previous_source_references/` — сохранённые ранее варианты MainActivity и Guardian.
- `legacy_reference_sources/` — исходные архивы Yandex/VK, AndroidAssistant и Mobile Installer, сохранённые отдельно как исторические ветки (не слиты автоматически из-за несовместимых Gradle/Android API версий).
- `firmware_research_scaffold/` — исследовательская структура будущей прошивки, НЕ готовая прошивка.

Важно: этот архив — исходный код, не APK и не прошивка. Не прошивать его через recovery. Реальные загрузочные логотипы и системные компоненты нельзя заменить обычным приложением.
