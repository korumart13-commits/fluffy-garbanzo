# Placeholder only — NOT a valid product definition.
# A real product makefile requires verified device-specific sources and configuration.
