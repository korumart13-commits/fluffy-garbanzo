# Flashing safety checklist

This scaffold is not flashable. No installation instructions are provided for it.

Before any future ROM installation, a maintainer must:
- Verify the exact hardware variant and firmware branch.
- Build from complete, matching sources and validate all required partitions.
- Verify AVB/vbmeta behavior, signing, rollback protection, and boot chain constraints.
- Test boot, recovery, encryption, radio, Wi-Fi, Bluetooth, camera, sensors, audio, charging, and thermal behavior.
- Confirm a reliable stock restore path and a complete backup.
- Provide device-specific, reviewed instructions with explicit risks.

Never flash generic `update.zip`, `boot.img`, `vbmeta.img`, `vendor_boot.img`, `dtbo.img`, or partition images based only on a marketing model name. A failed flash can erase data or render the device unbootable.
