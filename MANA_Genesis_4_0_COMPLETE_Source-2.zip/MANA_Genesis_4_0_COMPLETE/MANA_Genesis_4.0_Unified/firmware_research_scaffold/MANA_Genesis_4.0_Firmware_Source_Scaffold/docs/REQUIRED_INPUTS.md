# Required device evidence

Do not fill these fields by guessing.

1. Exact model shown in Settings → About device (including suffix/region).
2. Device codename reported by a trusted device-info tool or verified device documentation.
3. Full build number and Android security patch level.
4. Full build fingerprint (`ro.build.fingerprint`) and product/device identifiers (`ro.product.device`, `ro.product.vendor.device`).
5. SoC/platform and board name.
6. Bootloader unlock availability/status and the manufacturer's unlock procedure.
7. Matching stock firmware package for this exact variant and region.
8. Official kernel source and matching kernel configuration, if published.
9. Matching vendor blobs, HALs, VINTF manifest/matrix, firmware partitions and partition map.
10. A verified stock restore package and tested recovery route.

Useful read-only Android properties (for diagnostics only):

```sh
getprop ro.product.model
getprop ro.product.device
getprop ro.product.vendor.device
getprop ro.build.fingerprint
getprop ro.build.version.release
getprop ro.build.version.sdk
getprop ro.board.platform
getprop ro.boot.hardware
```

Do not publish IMEI, serial number, Android ID, account identifiers, passwords, or unlock tokens.
