# MANA Genesis 4.0 — Firmware Source Scaffold (NOT FLASHABLE)

This folder is a safe starting structure for researching a real AOSP-based replacement OS for the reported realme RMX5566 / realme C85 5G.

**IMPORTANT: This is NOT a ROM, recovery package, OTA, boot image, or installable ZIP. Do not flash it.** It intentionally contains no fabricated device tree, kernel, vendor blobs, partition map, boot image, AVB keys, or recovery updater.

## Why it cannot be installed yet
A replacement firmware must be built and validated for the exact hardware revision and software branch. The following are currently unverified/missing:
- Exact device codename and hardware variant
- Matching stock firmware and proprietary vendor blobs
- Device tree and BoardConfig values
- Kernel source/configuration and modules
- HAL/VINTF compatibility manifests and matrices
- Partition sizes/layout, dynamic partition metadata and filesystem choices
- Bootloader unlock state and verified-boot/AVB signing requirements
- Working recovery/fastbootd path and a tested restore procedure

Using guessed values can hard-brick the phone or make it impossible to boot or restore.

## Folder map
- `device/realme/RMX5566/` — placeholder for a device tree; intentionally incomplete.
- `vendor/realme/RMX5566/` — placeholder for legally obtained, device-matched proprietary files; empty by design.
- `kernel/realme/RMX5566/` — placeholder for the exact kernel source; empty by design.
- `firmware/` — place only verified stock firmware packages here; currently empty.
- `docs/REQUIRED_INPUTS.md` — evidence needed before any build can be attempted.
- `docs/FLASHING_SAFETY.md` — safety and recovery requirements.

## Next safe step
Collect the exact model/codename, full build fingerprint, region/firmware version, and matching stock firmware package. Then identify the official kernel source and device-specific vendor components. Only after those are verified should a device tree and build configuration be authored.

MANA branding, launcher, assistant, avatar, and apps can be developed as Android applications independently; they do not by themselves replace the Android operating system.
