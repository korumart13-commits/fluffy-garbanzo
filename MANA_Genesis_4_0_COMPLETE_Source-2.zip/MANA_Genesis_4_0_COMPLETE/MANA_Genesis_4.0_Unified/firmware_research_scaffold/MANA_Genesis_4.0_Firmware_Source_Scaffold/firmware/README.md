# Stock firmware placeholder

Empty by design. Keep an unmodified, verified stock firmware package for the exact model, region, and build here. Verify its source and integrity before using it for research or recovery.
