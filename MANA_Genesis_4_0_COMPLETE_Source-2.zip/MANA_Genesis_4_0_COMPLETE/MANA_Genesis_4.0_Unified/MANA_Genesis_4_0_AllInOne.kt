package com.mana.genesis

import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.CopyOnWriteArrayList

/**
 * MANA GENESIS 4.0 — unified core source.
 * Android/realme remain the host OS ("subconscious"); MANA is the user-facing
 * assistant layer ("consciousness"). This file contains no firmware flashing,
 * privilege escalation, malware execution, stealth, or destructive system code.
 */

object ManaGenesis {
    const val NAME = "MANA"
    const val VERSION = "4.0.0"
    const val CODENAME = "GENESIS"
    const val TARGET_DEVICE = "realme RMX5566 / realme C85 5G (variant must be verified)"
    const val BACKGROUND = "#071426"
    const val SURFACE = "#102B50"
    const val PRIMARY = "#1765A8"
    const val ACCENT = "#54C8F5"
    const val TEXT = "#EAF4FF"
    const val SECONDARY = "#91A9C5"

    enum class Module {
        BRAIN, LAUNCHER, SYSTEM_UI_BRIDGE, SETTINGS, CONTROL_CENTER, AVATAR,
        VOICE, MEMORY, DIARY, LIFE_MANAGER, CONTACT_INTELLIGENCE,
        SMART_RECEPTIONIST, CONNECT, ENGINEER, MOD_STUDIO, GAME_COMPANION,
        GUARDIAN, UPDATE_CENTER, ADAPTIVE_LEARNING, YANDEX, VK, RECOVERY_INFO
    }

    val modules = Module.entries.toList()
}

enum class PermissionScope {
    MICROPHONE, CONTACTS, PHONE_STATE, NOTIFICATIONS, BLUETOOTH,
    FILES, CAMERA, ACCESSIBILITY, DISPLAY_OVER_OTHER_APPS, INTERNET,
    GAME_BRIDGE, UPDATE_INSTALL
}

/** Explicit consent gate. No module silently grants itself Android permissions. */
class ManaConsent {
    private val granted = mutableSetOf<PermissionScope>()
    @Synchronized fun grant(scope: PermissionScope) { granted += scope }
    @Synchronized fun revoke(scope: PermissionScope) { granted -= scope }
    @Synchronized fun revokeAll() { granted.clear() }
    @Synchronized fun allows(scope: PermissionScope) = scope in granted
    @Synchronized fun snapshot(): Set<PermissionScope> = granted.toSet()
}

data class MemoryEntry(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val createdAt: Long = System.currentTimeMillis(),
    val category: String = "note"
)

/** Local memory/diary repository. Android app layer must persist it with Room/DataStore. */
class ManaMemory {
    private val entries = CopyOnWriteArrayList<MemoryEntry>()
    fun add(text: String, category: String = "note"): MemoryEntry {
        require(text.isNotBlank())
        return MemoryEntry(text = text.trim(), category = category).also(entries::add)
    }
    fun all(): List<MemoryEntry> = entries.sortedByDescending { it.createdAt }
    fun delete(id: String): Boolean = entries.removeIf { it.id == id }
    fun clear() = entries.clear()
}

data class GeneratedArtifact(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val kind: ArtifactKind,
    val content: String,
    val createdAt: Long = System.currentTimeMillis()
)
enum class ArtifactKind { CODE, TEXT, TABLE_CSV, JSON, HTML, GAME_MOD_SOURCE, PROJECT_PLAN }

/** The model/provider is injected by the Android app; this core never invents an API key. */
fun interface ManaGenerationProvider {
    suspend fun generate(instruction: String, outputKind: ArtifactKind): String
}

/** "IT engineer" workbench: creates text/code artifacts; user reviews before execution. */
class ManaEngineer(private val provider: ManaGenerationProvider) {
    suspend fun create(instruction: String, kind: ArtifactKind, fileName: String): GeneratedArtifact {
        require(instruction.isNotBlank())
        require(fileName.matches(Regex("[A-Za-z0-9._-]{1,100}")))
        val output = provider.generate(instruction, kind)
        require(output.isNotBlank())
        return GeneratedArtifact(name = fileName, kind = kind, content = output)
    }
}

/** A draft update is inert until the owner explicitly approves it. */
enum class ProposalState { IDEA, DRAFTED, APPROVED, REJECTED, PACKAGED, INSTALLED }
data class UpdateProposal(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val description: String,
    val state: ProposalState = ProposalState.IDEA,
    val createdAt: Long = System.currentTimeMillis()
)
class ManaUpdateCenter {
    private val proposals = CopyOnWriteArrayList<UpdateProposal>()
    fun submit(title: String, description: String): UpdateProposal {
        require(title.isNotBlank() && description.isNotBlank())
        return UpdateProposal(title = title, description = description).also(proposals::add)
    }
    fun all(): List<UpdateProposal> = proposals.toList()
    @Synchronized fun setState(id: String, next: ProposalState): UpdateProposal {
        val old = proposals.firstOrNull { it.id == id } ?: error("Proposal not found")
        require(allowed(old.state, next)) { "Invalid update workflow transition" }
        val updated = old.copy(state = next)
        proposals[proposals.indexOf(old)] = updated
        return updated
    }
    private fun allowed(from: ProposalState, to: ProposalState): Boolean = when (from) {
        ProposalState.IDEA -> to == ProposalState.DRAFTED || to == ProposalState.REJECTED
        ProposalState.DRAFTED -> to == ProposalState.APPROVED || to == ProposalState.REJECTED
        ProposalState.APPROVED -> to == ProposalState.PACKAGED || to == ProposalState.REJECTED
        ProposalState.PACKAGED -> to == ProposalState.INSTALLED || to == ProposalState.REJECTED
        ProposalState.REJECTED, ProposalState.INSTALLED -> false
    }
}

/** Android app delegates installation to PackageInstaller/system updater after verification. */
object ManaPackageVerifier {
    fun sha256(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
    fun matches(bytes: ByteArray, expectedSha256: String): Boolean =
        sha256(bytes).equals(expectedSha256.trim(), ignoreCase = true)
}

/** Read-only local security findings; actual malware removal belongs to trusted AV/Android tools. */
enum class FindingLevel { OK, INFO, WARNING, UNKNOWN }
data class SecurityFinding(val id: String, val title: String, val level: FindingLevel, val details: String)
data class SecurityReport(
    val createdAt: Long = System.currentTimeMillis(),
    val findings: List<SecurityFinding>
) {
    val warnings get() = findings.count { it.level == FindingLevel.WARNING }
}
class ManaGuardian {
    fun report(findings: List<SecurityFinding>) = SecurityReport(findings = findings.toList())
    fun safetyNote() =
        "Read-only audit. Do not run, copy, or learn operational behavior from malware. Quarantine and removal require owner confirmation and trusted security APIs."
}

/** Game companion adapter: integrate only through supported server/plugin/mod APIs. */
interface ManaGameBridge {
    suspend fun connect(serverOrWorld: String): Boolean
    suspend fun sendChat(message: String)
    suspend fun observePermittedState(): String
    suspend fun disconnect()
}
class ManaGameCompanion(private val bridge: ManaGameBridge) {
    suspend fun join(target: String): Boolean = bridge.connect(target)
    suspend fun assist(task: String) {
        require(task.isNotBlank())
        bridge.sendChat(task)
    }
    suspend fun status(): String = bridge.observePermittedState()
    suspend fun leave() = bridge.disconnect()
}

/** Learning is source-attributed and reviewable; no uncontrolled self-modification. */
data class LearningSource(val title: String, val uri: String, val retrievedAt: Long, val trustNote: String)
data class LearningRecord(val source: LearningSource, val summary: String, val acceptedByOwner: Boolean = false)
class ManaLearningCatalog {
    private val records = CopyOnWriteArrayList<LearningRecord>()
    fun propose(record: LearningRecord) { require(record.source.uri.startsWith("https://")); records += record }
    fun review(): List<LearningRecord> = records.toList()
    fun accept(idUri: String) {
        val index = records.indexOfFirst { it.source.uri == idUri }
        require(index >= 0)
        records[index] = records[index].copy(acceptedByOwner = true)
    }
}

/** Hardware integrations are implemented by Android APIs in app modules. */
interface ManaDeviceConnector {
    fun pairedDevices(): List<String>
    fun connectionState(deviceId: String): String
    fun openSystemBluetoothSettings()
}

/** Avatar/overlay must request Android overlay permission and remain user-dismissable. */
data class ManaAvatarPreferences(
    val enabled: Boolean = true,
    val fixedIdentity: String = "MANA",
    val outfitId: String = "default",
    val summonGesture: String = "in-app quick action / supported assistant shortcut"
)
interface ManaAvatarController {
    fun show()
    fun hide()
    fun setExpression(expression: String)
    fun setOutfit(outfitId: String)
}

/** Smart receptionist defaults retained from the agreed project configuration. */
data class ReceptionistConfig(
    val personality: String = "playful",
    val answerDelaySeconds: Int = 10,
    val summarizeConversations: Boolean = true,
    val specialUnknownNumberHandling: Boolean = true,
    val callHandlingRequiresUserEnabledRole: Boolean = true
)

/** Host OS remains authoritative for boot chain, SELinux, AVB, partitions and hardware. */
data class HostSystemRelationship(
    val host: String = "Android / realme system",
    val manaRole: String = "assistant, launcher, app suite and optional system-integrated layer",
    val mayReplaceFirmware: Boolean = false,
    val mayChangeBootLogoAsOrdinaryApp: Boolean = false
)
