package com.mana.os.guardian

import android.content.Context
import android.os.Build
import android.os.Debug
import android.provider.Settings
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * MANA Guardian — read-only Android security audit.
 *
 * This component does not hide itself, persist secretly, collect personal data,
 * access the network, change system settings, or modify device partitions.
 * The host app should call scan() only after the user opens the Guardian screen
 * or explicitly requests a scan.
 */
class MANA_Guardian(private val context: Context) {

    data class Finding(
        val id: String,
        val title: String,
        val status: Status,
        val details: String
    )

    enum class Status { OK, WARNING, INFO, UNKNOWN }

    data class Report(
        val generatedAt: String,
        val device: String,
        val androidVersion: String,
        val findings: List<Finding>
    ) {
        val warningCount: Int get() = findings.count { it.status == Status.WARNING }

        fun toPlainText(): String = buildString {
            appendLine("MANA GUARDIAN — SECURITY REPORT")
            appendLine("Created: $generatedAt")
            appendLine("Device: $device")
            appendLine("Android: $androidVersion")
            appendLine("Warnings: $warningCount")
            appendLine()
            findings.forEach { item ->
                appendLine("[${item.status}] ${item.title}")
                appendLine(item.details)
                appendLine()
            }
            appendLine("Note: heuristic checks only; this is not a malware scanner or a guarantee of device security.")
        }
    }

    /** Runs a local, read-only audit. No background work is started. */
    fun scan(): Report {
        val findings = mutableListOf<Finding>()

        val appInfo = context.applicationInfo
        findings += Finding(
            id = "app_debuggable",
            title = "Application build mode",
            status = if ((appInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) == 0) Status.OK else Status.WARNING,
            details = if ((appInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) == 0)
                "The installed MANA app is not marked debuggable."
            else "This app build is debuggable. Use a release-signed build for normal use."
        )

        val adbEnabled = readGlobalSetting(Settings.Global.ADB_ENABLED)
        findings += Finding(
            id = "adb",
            title = "USB debugging (ADB)",
            status = when (adbEnabled) { 0 -> Status.OK; 1 -> Status.WARNING; else -> Status.UNKNOWN },
            details = when (adbEnabled) { 0 -> "ADB is reported as disabled."; 1 -> "ADB is enabled. Disable it when you do not need it."; else -> "The setting could not be read on this Android version." }
        )

        val devOptions = readGlobalSetting(Settings.Global.DEVELOPMENT_SETTINGS_ENABLED)
        findings += Finding(
            id = "developer_options",
            title = "Developer options",
            status = when (devOptions) { 0 -> Status.INFO; 1 -> Status.WARNING; else -> Status.UNKNOWN },
            details = when (devOptions) { 0 -> "Developer options are reported as disabled."; 1 -> "Developer options are enabled; review enabled debugging features."; else -> "The setting could not be read." }
        )

        val selinuxEnforcing = runCatching {
            File("/sys/fs/selinux/enforce").takeIf { it.canRead() }?.readText()?.trim() == "1"
        }.getOrNull()
        findings += Finding(
            id = "selinux",
            title = "SELinux enforcement",
            status = when (selinuxEnforcing) { true -> Status.OK; false -> Status.WARNING; null -> Status.UNKNOWN },
            details = when (selinuxEnforcing) { true -> "SELinux reports enforcing mode."; false -> "SELinux does not report enforcing mode. Investigate before using this device for sensitive work."; null -> "SELinux state could not be read by this app." }
        )

        val rootIndicators = listOf(
            "/system/bin/su", "/system/xbin/su", "/sbin/su", "/system/app/Superuser.apk",
            "/system/bin/.ext/.su", "/data/adb/magisk"
        ).filter { path -> File(path).exists() }
        findings += Finding(
            id = "root_indicators",
            title = "Root-related indicators",
            status = if (rootIndicators.isEmpty()) Status.OK else Status.WARNING,
            details = if (rootIndicators.isEmpty())
                "No common root-related paths were found. This does not prove the device is unrooted."
            else "Common root-related paths were found: ${rootIndicators.joinToString()}. This may be intentional; verify the device configuration."
        )

        findings += Finding(
            id = "debugger",
            title = "Debugger attachment",
            status = if (Debug.isDebuggerConnected()) Status.WARNING else Status.OK,
            details = if (Debug.isDebuggerConnected()) "A debugger is currently attached to this app process." else "No debugger is currently attached to this app process."
        )

        findings += Finding(
            id = "verified_boot",
            title = "Verified Boot information",
            status = Status.INFO,
            details = "Build fingerprint: ${Build.FINGERPRINT}. This app does not change bootloader, AVB, rollback protection, or system partitions. Verify boot state in the device's trusted system interface."
        )

        val formatter = SimpleDateFormat("yyyy-MM-dd HH:mm:ss Z", Locale.US)
        return Report(
            generatedAt = formatter.format(Date()),
            device = "${Build.MANUFACTURER} ${Build.MODEL} (${Build.DEVICE})",
            androidVersion = "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            findings = findings
        )
    }

    private fun readGlobalSetting(name: String): Int? = runCatching {
        Settings.Global.getInt(context.contentResolver, name)
    }.getOrNull()
}
