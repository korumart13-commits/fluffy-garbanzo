# MANA OS — Android shell prototype

Этот репозиторий — прототип системной оболочки MANA поверх Android, а не самостоятельная прошивка. Android остаётся базовой ОС и предоставляет драйверы, безопасность, приложения и системные API.

Основной пользовательский вход — `ManaHomeActivity` (HOME launcher). Диалог с ассистентом доступен отдельной кнопкой и сохраняет прежний `MainActivity`.

Сборка: Android Studio, JDK 17, Android SDK 34, Gradle Wrapper 8.5.

Подробности и ограничения: `MANA_OS_STATUS_RU.md`, `MANA_OS_ROADMAP_RU.md`, `ARCHITECTURE_MANA.md`.
