#!/bin/sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
MANIFEST="$ROOT/MANA_OS_UPDATE.json"
SOURCE="$ROOT/source/MANA_OS_3.0_YANDEX_VK_SOURCE.zip"
[ -f "$MANIFEST" ] || { echo "ERROR: manifest missing"; exit 2; }
[ -f "$SOURCE" ] || { echo "ERROR: original source archive missing"; exit 2; }
if command -v sha256sum >/dev/null 2>&1; then
  EXPECTED=$(sed -n 's/.*"source_archive_sha256": "\([0-9a-f]*\)".*/\1/p' "$MANIFEST")
  ACTUAL=$(sha256sum "$SOURCE" | awk '{print $1}')
  [ -n "$EXPECTED" ] && [ "$EXPECTED" = "$ACTUAL" ] || { echo "ERROR: source archive hash mismatch"; exit 3; }
fi
echo "Package structure OK."
echo "NOTICE: no device-specific signed firmware payload is included."
echo "FLASHING ABORTED: this container is not a flashable OTA yet."
exit 10
