package com.mana.installer

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/** Read-only device audit. It never writes partitions, changes boot settings or invokes root. */
class MainActivity : Activity() {
    private lateinit var reportView: TextView
    private var latestReport: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        renderHome()
        runDiagnostics()
    }

    private fun renderHome() {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(7, 20, 38)) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(22), dp(28), dp(22), dp(28))
        }
        root.addView(label("MANA", 38f, "#54C8F5").apply { gravity = Gravity.CENTER })
        root.addView(label("MOBILE INSTALLER  •  VERSION 1.1.0", 12f, "#91A9C5"))
        root.addView(label("Расширенная read-only диагностика заводской сборки, vendor, VINTF, kernel, HAL, AVB и разделов. Ничего не прошивается и не изменяется.", 15f, "#EAF4FF"))
        root.addView(section("ОТЧЁТ СОВМЕСТИМОСТИ"))
        reportView = label("Выполняется диагностика…", 13f, "#EAF4FF").apply {
            setBackgroundColor(Color.rgb(16, 43, 80)); setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        root.addView(reportView, matchWrap())
        root.addView(section("ДЕЙСТВИЯ"))
        root.addView(actionButton("Повторить полную проверку") { runDiagnostics() })
        root.addView(actionButton("Сохранить подробный отчёт") { saveReport() })
        root.addView(actionButton("Оценить готовность MANA OS") { showInstallReadiness() })
        root.addView(label("Важно: отсутствие доступа к системному файлу не считается успехом. Совместимость прошивки не подтверждается только совпадением модели. Не отключайте AVB/Verified Boot и SELinux.", 12f, "#91A9C5"))
        scroll.addView(root); setContentView(scroll)
    }

    private data class Check(val name: String, val status: String, val detail: String)

    private fun runDiagnostics() {
        val checks = mutableListOf<Check>()
        val props = linkedMapOf<String, String>()
        val propertyKeys = listOf(
            "ro.product.manufacturer", "ro.product.brand", "ro.product.model", "ro.product.device", "ro.product.name",
            "ro.build.fingerprint", "ro.build.display.id", "ro.build.version.release", "ro.build.version.sdk",
            "ro.build.version.security_patch", "ro.build.type", "ro.build.tags", "ro.build.flavor",
            "ro.vendor.build.fingerprint", "ro.vendor.build.version.release", "ro.vendor.build.security_patch",
            "ro.bootimage.build.fingerprint", "ro.bootloader", "ro.hardware", "ro.board.platform",
            "ro.boot.verifiedbootstate", "ro.boot.vbmeta.device_state", "ro.boot.flash.locked",
            "ro.boot.veritymode", "ro.boot.avb_version", "ro.boot.slot_suffix", "ro.build.ab_update"
        )
        propertyKeys.forEach { key -> props[key] = getProperty(key) }

        val model = Build.MODEL.orEmpty()
        val device = Build.DEVICE.orEmpty()
        val product = Build.PRODUCT.orEmpty()
        val targetModel = model.contains("RMX5566", true) || props["ro.product.model"].orEmpty().contains("RMX5566", true)
        checks += Check("Идентификация устройства", if (targetModel) "MATCH" else "NOT CONFIRMED",
            "Build.MODEL=$model; DEVICE=$device; PRODUCT=$product; ожидаемая модель RMX5566")

        val fingerprint = props["ro.build.fingerprint"].orEmpty()
        val vendorFp = props["ro.vendor.build.fingerprint"].orEmpty()
        val isUserBuild = props["ro.build.type"] == "user" && props["ro.build.tags"] == "release-keys"
        val factoryEvidence = when {
            fingerprint.isBlank() -> "UNKNOWN"
            isUserBuild && vendorFp.isNotBlank() -> "FACTORY-LIKE (NOT AUTHENTICATED)"
            else -> "NOT VERIFIED"
        }
        checks += Check("Заводская прошивка", factoryEvidence,
            "Build fingerprint=$fingerprint; build type=${props["ro.build.type"]}; tags=${props["ro.build.tags"]}; vendor fingerprint=$vendorFp. Эти свойства не доказывают подлинность OTA/заводского образа без эталонной подписи производителя.")

        val vendorDetail = listOf("ro.vendor.build.fingerprint", "ro.vendor.build.version.release", "ro.vendor.build.security_patch", "ro.hardware", "ro.board.platform")
            .joinToString("; ") { "$it=${props[it].orEmpty().ifBlank { "недоступно" }}" }
        checks += Check("Vendor", if (vendorFp.isNotBlank()) "READ" else "PARTIAL", vendorDetail)

        val kernel = try { File("/proc/version").takeIf { it.canRead() }?.readText()?.trim()?.take(700) } catch (_: Exception) { null }
        val kernelRelease = System.getProperty("os.version", "unknown")
        checks += Check("Kernel", if (!kernel.isNullOrBlank()) "READ" else "PARTIAL", "os.version=$kernelRelease; /proc/version=${kernel ?: "недоступен"}; ABI=${Build.SUPPORTED_ABIS.joinToString()}")

        val vintfPaths = listOf(
            "/vendor/etc/vintf/manifest.xml", "/vendor/etc/vintf/manifest", "/odm/etc/vintf/manifest.xml",
            "/system/etc/vintf/manifest.xml", "/system_ext/etc/vintf/manifest.xml", "/vendor/manifest.xml"
        )
        val vintfFound = mutableListOf<String>()
        val vintfDenied = mutableListOf<String>()
        vintfPaths.forEach { path ->
            val f = File(path)
            if (f.exists()) {
                if (f.canRead()) {
                    val content = try { f.readText().take(256 * 1024) } catch (_: Exception) { "" }
                    if (content.isNotBlank()) vintfFound += "$path (${content.length} chars, sha256=${sha256(content)})"
                    else vintfDenied += "$path (empty/unreadable)"
                } else vintfDenied += "$path (permission denied)"
            }
        }
        checks += Check("VINTF manifests", if (vintfFound.isNotEmpty()) "FILES READ; COMPATIBILITY NOT TESTED" else "UNAVAILABLE",
            (vintfFound + vintfDenied).joinToString("\n").ifBlank { "Стандартные пути VINTF не видны приложению. Нужны vendor/odm/system manifests и проверка checkvintf для конкретной сборки." })

        val halEvidence = listOf("/vendor/etc/vintf/manifest.xml", "/vendor/etc/vintf/manifest", "/odm/etc/vintf/manifest.xml")
            .mapNotNull { p -> try { File(p).takeIf { it.canRead() }?.readText()?.take(256 * 1024)?.let { p to it } } catch (_: Exception) { null } }
        val halNames = halEvidence.flatMap { (path, body) -> Regex("<name>([^<]+)</name>").findAll(body).map { "$path: ${it.groupValues[1]}" }.toList() }.distinct().take(80)
        checks += Check("HAL", if (halNames.isNotEmpty()) "DECLARATIONS READ; RUNTIME NOT VERIFIED" else "UNAVAILABLE",
            if (halNames.isNotEmpty()) halNames.joinToString("\n") else "HAL declarations не удалось прочитать. Наличие и версии сервисов HAL требуют device-side VINTF/service validation; root не используется.")

        val avbState = props["ro.boot.verifiedbootstate"].orEmpty()
        val lockState = props["ro.boot.flash.locked"].orEmpty()
        val vbmetaState = props["ro.boot.vbmeta.device_state"].orEmpty()
        val avbStatus = when {
            avbState == "green" && lockState == "1" && vbmetaState == "locked" -> "GREEN / LOCKED (PROPERTY EVIDENCE)"
            avbState.isBlank() && lockState.isBlank() -> "UNKNOWN"
            else -> "REVIEW REQUIRED"
        }
        checks += Check("AVB / Verified Boot", avbStatus,
            "verifiedbootstate=${avbState.ifBlank { "unknown" }}; flash.locked=${lockState.ifBlank { "unknown" }}; vbmeta.device_state=${vbmetaState.ifBlank { "unknown" }}; veritymode=${props["ro.boot.veritymode"]}; slot=${props["ro.boot.slot_suffix"]}. Свойства загрузки не заменяют криптографическую проверку vbmeta chain и rollback indexes.")

        val partitionPaths = listOf("/dev/block/by-name", "/dev/block/bootdevice/by-name", "/dev/block/platform")
        val partitionLines = mutableListOf<String>()
        partitionPaths.forEach { path ->
            val f = File(path)
            if (f.exists() && f.canRead()) {
                val listing = try { f.list()?.sorted()?.take(120) } catch (_: Exception) { null }
                if (!listing.isNullOrEmpty()) partitionLines += "$path: ${listing.joinToString(", ")}"
                else if (f.isDirectory) partitionLines += "$path: каталог доступен, список пуст/запрещён"
            } else partitionLines += "$path: ${if (f.exists()) "permission denied" else "not exposed"}"
        }
        val partStatus = if (partitionLines.any { it.contains(": ") && !it.contains("not exposed") && !it.contains("permission denied") }) "PARTIAL READ" else "UNAVAILABLE"
        checks += Check("Разметка разделов", partStatus,
            partitionLines.joinToString("\n") + "\nПримечание: имена разделов не раскрывают точные размеры, offsets, super/dynamic partition metadata или fstab. Для этого нужен доверенный stock scatter/OTA metadata или read-only device tooling.")

        val bootProps = listOf("ro.boot.hardware", "ro.boot.product.hardware.sku", "ro.boot.product.vendor.sku", "ro.bootloader", "ro.hardware", "ro.board.platform")
            .joinToString("; ") { "$it=${props[it].orEmpty().ifBlank { "unknown" }}" }
        checks += Check("Платформа / аппаратная ревизия", "INFORMATIONAL", bootProps)

        val passCount = checks.count { it.status == "MATCH" || it.status.startsWith("GREEN") }
        val unknownCount = checks.count { it.status.contains("UNKNOWN") || it.status.contains("UNAVAILABLE") || it.status.contains("PARTIAL") }
        val overall = "НЕ ПОДТВЕРЖДЕНА — $passCount подтверждающих сигналов; $unknownCount неполных/недоступных проверок. Никакого разрешения на прошивку не выдано."
        latestReport = buildString {
            appendLine("MANA MOBILE INSTALLER — EXTENDED READ-ONLY AUDIT")
            appendLine("Дата: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())}")
            appendLine("Версия приложения: 1.1.0")
            appendLine("ИТОГ: $overall")
            appendLine("\n=== ОСНОВНЫЕ ДАННЫЕ ===")
            appendLine("Manufacturer=${Build.MANUFACTURER}; Brand=${Build.BRAND}; Model=${Build.MODEL}; Device=${Build.DEVICE}; Product=${Build.PRODUCT}")
            appendLine("Android=${Build.VERSION.RELEASE}; API=${Build.VERSION.SDK_INT}; security patch=${Build.VERSION.SECURITY_PATCH}; ABI=${Build.SUPPORTED_ABIS.joinToString()}")
            appendLine("\n=== ПРОВЕРКИ ===")
            checks.forEachIndexed { i, c -> appendLine("\n${i + 1}. ${c.name}\nСТАТУС: ${c.status}\n${c.detail}") }
            appendLine("\n=== BUILD PROPERTIES (READ-ONLY) ===")
            props.forEach { (k, v) -> appendLine("$k=${v.ifBlank { "<empty or inaccessible>" }}") }
            appendLine("\n=== ВАЖНЫЕ ОГРАНИЧЕНИЯ ===")
            appendLine("1. Приложение работает без root и не читает IMEI, серийный номер, контакты или пользовательские файлы.")
            appendLine("2. Заводское происхождение нельзя доказать по build properties. Нужен официальный пакет realme для точной модели/региона и проверка подписи/хешей.")
            appendLine("3. VINTF/HAL требуют полноценной проверки совместимости (например, checkvintf) вместе с целевыми framework/vendor manifests.")
            appendLine("4. Kernel должен совпадать с device tree, defconfig, modules, vendor_boot/init_boot и ABI конкретной ревизии.")
            appendLine("5. Для partition layout нужны точные размеры/слоты/dynamic partition metadata из проверенного stock firmware; простого списка имён недостаточно.")
            appendLine("6. AVB свойства — только диагностические сигналы, не криптографическая аттестация vbmeta и rollback protection.")
            appendLine("7. Итоговый статус намеренно не может стать READY TO FLASH без внешнего эталона и полной device-specific валидации.")
            appendLine("\nБезопасность: никаких операций записи, форматирования, fastboot, разблокировки загрузчика, отключения AVB/SELinux или изменения системных свойств.")
        }
        reportView.text = latestReport
    }

    private fun getProperty(key: String): String = try {
        val p = ProcessBuilder("/system/bin/getprop", key).redirectErrorStream(true).start()
        if (!p.waitFor(2, TimeUnit.SECONDS)) { p.destroyForcibly(); "" }
        else p.inputStream.bufferedReader().use { it.readText().trim().take(1000) }
    } catch (_: Exception) { "" }

    private fun sha256(value: String): String = try {
        MessageDigest.getInstance("SHA-256").digest(value.toByteArray()).joinToString("") { "%02x".format(it) }.take(24)
    } catch (_: Exception) { "unavailable" }

    private fun showInstallReadiness() {
        android.app.AlertDialog.Builder(this)
            .setTitle("MANA OS — готовность установки")
            .setMessage("Результат остаётся «НЕ ПОДТВЕРЖДЕНА», пока не проверены официальный factory firmware именно для RMX5566 и региона, подписи/хеши, полный VINTF через checkvintf, HAL, kernel/device tree/modules, точная разметка разделов и AVB chain. Недоступные приложению данные отмечаются как UNKNOWN, а не как PASS. Установка/прошивка не выполняется.")
            .setPositiveButton("Понятно", null).show()
    }

    private fun saveReport() {
        if (latestReport.isBlank()) runDiagnostics()
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "text/plain"; putExtra(Intent.EXTRA_TITLE, "MANA_RMX5566_compatibility_report.txt")
        }
        startActivityForResult(intent, REQUEST_SAVE)
    }

    @Deprecated("Using activity result for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_SAVE && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(latestReport) }
                android.app.AlertDialog.Builder(this).setMessage("Подробный отчёт сохранён.").setPositiveButton("OK", null).show()
            } catch (e: Exception) {
                android.app.AlertDialog.Builder(this).setMessage("Ошибка сохранения: ${e.message}").setPositiveButton("OK", null).show()
            }
        }
    }

    private fun section(text: String) = label(text, 12f, "#54C8F5").apply { setPadding(0, dp(22), 0, dp(8)) }
    private fun label(text: String, size: Float, color: String) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(Color.parseColor(color)); setPadding(0, dp(8), 0, dp(8))
    }
    private fun actionButton(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text; isAllCaps = false; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(23, 101, 168))
        setOnClickListener { action() }; layoutParams = LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(8) }
    }
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    companion object { private const val REQUEST_SAVE = 7041 }
}
