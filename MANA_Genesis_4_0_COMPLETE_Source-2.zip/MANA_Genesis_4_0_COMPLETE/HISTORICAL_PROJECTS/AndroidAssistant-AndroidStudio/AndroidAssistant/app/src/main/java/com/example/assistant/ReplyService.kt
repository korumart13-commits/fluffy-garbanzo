package com.example.assistant

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Автоответ: на входящее личное сообщение в известном мессенджере отвечает заданным текстом
 * (один раз на собеседника за 6 часов). Группы, банки и СМС не трогает.
 */
class ReplyService : NotificationListenerService() {
    private val last = HashMap<String, Long>()
    private val allowed = setOf(
        "org.telegram.messenger", "org.telegram.messenger.web", "com.whatsapp", "com.whatsapp.w4b",
        "com.vkontakte.android", "com.viber.voip", "org.thoughtcrime.securesms")

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val sp = getSharedPreferences("cfg", MODE_PRIVATE)
        if (!sp.getBoolean("autoreply", false)) return
        if (sbn.packageName !in allowed) return
        val n = sbn.notification ?: return
        if (n.category != Notification.CATEGORY_MESSAGE) return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val ex = n.extras ?: return
        if (ex.getBoolean("android.isGroupConversation", false)) return
        val who = ex.getCharSequence("android.title")?.toString() ?: return
        val key = sbn.packageName + "|" + who
        val now = System.currentTimeMillis()
        if (now - (last[key] ?: 0L) < 6 * 3_600_000L) return
        val act = n.actions?.firstOrNull { a -> a.remoteInputs?.isNotEmpty() == true } ?: return
        val inputs = act.remoteInputs ?: return
        val text = sp.getString("autotext", null) ?: Local.DEFAULT_AUTOTEXT
        val results = Bundle()
        for (r in inputs) results.putCharSequence(r.resultKey, text)
        val intent = Intent()
        RemoteInput.addResultsToIntent(inputs, intent, results)
        try { act.actionIntent.send(this, 0, intent); last[key] = now } catch (e: PendingIntent.CanceledException) { }
    }
}
