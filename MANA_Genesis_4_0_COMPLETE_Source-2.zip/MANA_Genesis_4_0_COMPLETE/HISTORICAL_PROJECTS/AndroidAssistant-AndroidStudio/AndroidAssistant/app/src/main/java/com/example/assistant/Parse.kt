package com.example.assistant

/** Разбор времени и имён из речи (чистый Kotlin, без Android). */
object Parse {
    fun plural(n: Int, one: String, few: String, many: String): String = when {
        n % 10 == 1 && n % 100 != 11 -> one
        n % 10 in 2..4 && n % 100 !in 12..14 -> few
        else -> many
    }

    fun human(sec: Int): String {
        val h = sec / 3600
        val m = (sec % 3600) / 60
        val s = sec % 60
        val parts = ArrayList<String>()
        if (h > 0) parts.add("$h ${plural(h, "час", "часа", "часов")}")
        if (m > 0) parts.add("$m ${plural(m, "минута", "минуты", "минут")}")
        if (h == 0 && m == 0) parts.add("$s ${plural(s, "секунда", "секунды", "секунд")}")
        return parts.joinToString(" ")
    }

    private val numWords = mapOf(
        "ноль" to 0, "один" to 1, "одну" to 1, "два" to 2, "две" to 2, "три" to 3, "четыре" to 4,
        "пять" to 5, "шесть" to 6, "семь" to 7, "восемь" to 8, "девять" to 9, "десять" to 10,
        "одиннадцать" to 11, "двенадцать" to 12, "пятнадцать" to 15, "двадцать" to 20,
        "тридцать" to 30, "сорок" to 40, "пятьдесят" to 50)

    /** «семь тридцать» -> «7 30» */
    fun digits(s: String): String = s.split(" ").joinToString(" ") { numWords[it]?.toString() ?: it }

    private val durRe = Regex("""(\d+)\s*(час[а-яё]*|ч|мин[а-яё]*|сек[а-яё]*)""")

    /** «10 минут», «1 час 30 минут», «полчаса» -> секунды */
    fun duration(s: String): Int? {
        val t = s.trim()
        if (t == "полчаса") return 1800
        if (t == "час") return 3600
        if (t == "минуту" || t == "минутку") return 60
        var total = 0
        var found = false
        for (m in durRe.findAll(t)) {
            val n = m.groupValues[1].toInt()
            val u = m.groupValues[2]
            total += when {
                u.startsWith("час") || u == "ч" -> n * 3600
                u.startsWith("мин") -> n * 60
                else -> n
            }
            found = true
        }
        return if (found && total > 0) total else null
    }

    private val clockRe = Regex("""(\d{1,2})(?:[:.\s](\d{2}))?\s*(утра|дня|вечера|ночи)?""")

    /** «7:30», «7 30», «8 вечера» -> (час, минуты) */
    fun clock(s: String): Pair<Int, Int>? {
        val m = clockRe.find(digits(s.trim())) ?: return null
        var h = m.groupValues[1].toInt()
        val min = if (m.groupValues[2].isEmpty()) 0 else m.groupValues[2].toInt()
        when (m.groupValues[3]) {
            "вечера", "дня" -> if (h in 1..11) h += 12
            "ночи" -> if (h == 12) h = 0
        }
        return if (h in 0..23 && min in 0..59) Pair(h, min) else null
    }

    private val lead = Regex("""^(?:что|про|о|об|чтобы)\s+""")
    private fun msg(s: String) = s.trim().replace(lead, "")

    private val inRe = Regex("""^((?:\d+\s*(?:час[а-яё]*|мин[а-яё]*|сек[а-яё]*)\s*)+|полчаса|час|минуту)\s*(.*)$""")

    /** «15 минут про чай» -> (900, «чай») */
    fun reminderIn(rest: String): Pair<Int, String>? {
        val m = inRe.matchEntire(digits(rest.trim())) ?: return null
        val d = duration(m.groupValues[1].trim()) ?: return null
        return Pair(d, msg(m.groupValues[2]))
    }

    private val atRe = Regex("""^(\d{1,2}(?:[:.\s]\d{2})?(?:\s*(?:утра|дня|вечера|ночи))?)\s*(.*)$""")

    /** «18:00 позвонить маме» -> (18, 0, «позвонить маме») */
    fun reminderAt(rest: String): Triple<Int, Int, String>? {
        val m = atRe.matchEntire(digits(rest.trim())) ?: return null
        val c = clock(m.groupValues[1]) ?: return null
        return Triple(c.first, c.second, msg(m.groupValues[2]))
    }

    /** Имя в разных падежах: «мама», «маме», «мамы» считаются одним именем. */
    fun same(a: String, b: String): Boolean {
        val x = a.lowercase().trim()
        val y = b.lowercase().trim()
        if (x.isEmpty() || y.isEmpty()) return false
        val n = minOf(3, x.length, y.length)
        return x.take(n) == y.take(n)
    }
}
