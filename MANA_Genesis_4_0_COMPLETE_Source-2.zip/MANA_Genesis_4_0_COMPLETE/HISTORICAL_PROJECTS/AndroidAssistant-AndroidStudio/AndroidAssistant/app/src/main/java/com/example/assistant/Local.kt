package com.example.assistant

import android.app.AppOpsManager
import android.app.NotificationManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Process
import android.provider.AlarmClock
import android.provider.Settings
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Результат разбора команды без ИИ: что сказать, какие действия выполнить на экране. */
class LocalResult(
    val say: String = "",
    val actions: List<JSONObject> = emptyList(),
    val stopSpeech: Boolean = false,
    val unknown: Boolean = false)

/** Режим без API-ключа: готовые команды + открытые сервисы (Википедия, Open-Meteo, поиск в браузере). */
object Local {
    private val ru = Locale("ru")

    private val aliases = mapOf(
        "ютуб" to listOf("youtube", "ютуб"),
        "телеграм" to listOf("telegram", "телеграм"),
        "телегу" to listOf("telegram", "телеграм"),
        "ватсап" to listOf("whatsapp"),
        "вацап" to listOf("whatsapp"),
        "вк" to listOf("вконтакте", "vk"),
        "вконтакте" to listOf("вконтакте", "vk"),
        "хром" to listOf("chrome"),
        "браузер" to listOf("chrome", "браузер", "browser", "firefox"),
        "камеру" to listOf("камера", "camera"),
        "камера" to listOf("камера", "camera"),
        "настройки" to listOf("настройки", "settings"),
        "галерею" to listOf("галерея", "gallery", "фото", "photos"),
        "галерея" to listOf("галерея", "gallery", "фото", "photos"),
        "фото" to listOf("фото", "photos", "галерея", "gallery"),
        "калькулятор" to listOf("калькулятор", "calculator"),
        "карты" to listOf("карты", "maps"),
        "почту" to listOf("gmail", "почта", "mail"),
        "почта" to listOf("gmail", "почта", "mail"),
        "музыку" to listOf("музыка", "music", "spotify"),
        "музыка" to listOf("музыка", "music", "spotify"),
        "часы" to listOf("часы", "clock"),
        "будильник" to listOf("часы", "clock"),
        "контакты" to listOf("контакты", "contacts"),
        "телефон" to listOf("телефон", "phone", "dialer"),
        "сообщения" to listOf("сообщения", "messages"),
        "плей маркет" to listOf("play маркет", "play store", "google play"),
        "яндекс" to listOf("яндекс", "yandex"),
        "сбер" to listOf("сбер", "sber"),
        "сбербанк" to listOf("сбер", "sber"))

    const val DEFAULT_AUTOTEXT = "Сейчас не могу ответить, отвечу позже. (автоответ)"

    /** hasAi = true: непонятные фразы возвращаются как unknown, чтобы их разобрал Claude. */
    fun handle(ctx: Context, raw: String, name: String, hasAi: Boolean = false): LocalResult =
        try { route(ctx, raw, name, hasAi) }
        catch (e: IOException) { LocalResult("Нет связи с интернетом. Проверьте сеть и повторите.") }

    private fun route(ctx: Context, raw: String, name: String, hasAi: Boolean): LocalResult {
        var t = raw.lowercase(ru).replace("пожалуйста", " ")
            .replace(Regex("""(?<!\d)[.,]|[.,](?!\d)|[!?;:«»"]"""), " ")
            .replace(Regex("\\s+"), " ").trim()
        val nm = name.lowercase(ru).trim()
        if (nm.isNotEmpty() && t.startsWith(nm)) t = t.removePrefix(nm).trim()
        if (t.isEmpty()) return LocalResult("Слушаю вас.")
        Learn.macro(ctx, t)?.let { t = it }   // свои команды, которым ассистента научили
        fun m(p: String) = Regex(p).matchEntire(t)
        fun act(type: String, vararg kv: Pair<String, String>) =
            LocalResult(actions = listOf(JSONObject().put("type", type).apply { kv.forEach { put(it.first, it.second) } }))

        if (m("стоп|замолчи|хватит|тихо|молчи") != null) return LocalResult(stopSpeech = true)
        if (m("что ты умеешь|что ты можешь|помощь|команды|помоги") != null) return LocalResult(
            "Я умею открывать приложения: «открой ютуб». Искать в интернете: «найди в интернете рецепт борща». " +
            "Рассказывать из Википедии: «что такое чёрная дыра». Говорить погоду: «погода в Москве». " +
            "Называть время и дату, считать: «посчитай 12 умножить на 7», набирать номер: «позвони 112». " +
            "Управлять экраном: «назад», «домой», «вниз», «нажми» и название кнопки. " +
            "Ставить будильники и таймеры: «разбуди меня в 7», «напомни через 15 минут про чай». " +
            "Включать режим сна, говорить, сколько вы сидите в телефоне, отвечать в мессенджерах: «включи автоответ». " +
            "Запоминать: «запомни номер мамы +7…», «когда я говорю привет, делай погода в Москве».")
        if (m("как тебя зовут|кто ты") != null) return LocalResult("Меня зовут $name.")
        if (m("привет|здравствуй|здравствуйте|добрый день|добрый вечер|хай") != null)
            return LocalResult("Привет! Чем помочь?")
        if (m("спасибо|благодарю") != null) return LocalResult("Пожалуйста!")

        // ---------- обучение и память ----------
        m("""когда я (?:говорю|скажу) (.+?) (?:то )?(?:делай|выполни|сделай|выполняй) (.+)""")?.let {
            Learn.addMacro(ctx, it.groupValues[1], it.groupValues[2])
            return LocalResult("Хорошо. Теперь на «${it.groupValues[1]}» я буду выполнять «${it.groupValues[2]}».")
        }
        m("""забудь команду (.+)""")?.let {
            return LocalResult(if (Learn.removeMacro(ctx, it.groupValues[1])) "Забыл команду «${it.groupValues[1]}»." else "Такой команды я не учил.")
        }
        if (m("что ты выучил|какие команды ты выучил|какие у тебя свои команды") != null) {
            val l = Learn.macros(ctx)
            return LocalResult(if (l.isEmpty()) "Пока ничему не научился. Скажите: «когда я говорю привет, делай погода в Москве»."
                else "Я выучил: " + l.joinToString("; ") { "${it.first} — ${it.second}" })
        }
        m("""запомни номер (.+?)\s+(\+?\d[\d\s()-]{5,})""")?.let {
            Learn.addContact(ctx, it.groupValues[1], it.groupValues[2].replace(Regex("[\\s()-]"), ""))
            return LocalResult("Запомнил номер: ${it.groupValues[1]}.")
        }
        m("""запомни (?:что )?(.+)""")?.let { Memory.add(ctx, it.groupValues[1]); return LocalResult("Запомнил.") }
        if (m("что ты помнишь|что ты знаешь обо мне") != null) {
            val f = Memory.all(ctx).split("\n").filter { it.isNotBlank() }
            val c = Learn.contactNames(ctx)
            if (f.isEmpty() && c.isEmpty()) return LocalResult("Пока ничего не помню.")
            return LocalResult("Я помню: " + f.joinToString("; ") + (if (c.isNotEmpty()) ". Номера: " + c.joinToString(", ") else ""))
        }
        if (m("забудь все|забудь всё|очисти память") != null) { Memory.clear(ctx); Learn.clearAll(ctx); return LocalResult("Память очищена.") }
        if (m("что ты не понял|что ты не понимаешь|что ты не понимал|покажи что ты не понял") != null) {
            val u = Learn.unknown(ctx)
            return LocalResult(if (u.isEmpty()) "Всё, что вы говорили, я понял." else "Я не понял: " + u.takeLast(8).joinToString("; "))
        }
        if (m("очисти список непонятного") != null) { Learn.clearUnknown(ctx); return LocalResult("Список очищен.") }

        // ---------- режим сна ----------
        if (m("(?:включи )?режим сна|спокойной ночи|(?:включи )?не беспокоить|(?:включи )?тихий режим") != null) return dnd(ctx, true)
        if (m("(?:выключи|отключи) (?:режим сна|не беспокоить|тихий режим)|доброе утро|я проснулся") != null) return dnd(ctx, false)

        // ---------- будильники, таймеры, напоминания ----------
        m("""(?:(?:поставь|заведи|установи|включи)\s+)?будильник\s+(?:на|в)\s+(.+)""")?.let {
            val c = Parse.clock(it.groupValues[1]) ?: return LocalResult("Не понял время. Скажите, например: «поставь будильник на 7:30».")
            return alarm(ctx, c.first, c.second, "Будильник")
        }
        m("""разбуди меня (?:в|на)\s+(.+)""")?.let {
            val c = Parse.clock(it.groupValues[1]) ?: return LocalResult("Не понял время. Скажите, например: «разбуди меня в 7 утра».")
            return alarm(ctx, c.first, c.second, "Подъём")
        }
        m("""(?:(?:поставь|заведи|установи|включи)\s+)?таймер\s+на\s+(.+)""")?.let {
            val sec = Parse.duration(Parse.digits(it.groupValues[1])) ?: return LocalResult("Не понял время. Скажите, например: «таймер на 10 минут».")
            return timer(ctx, sec, "Таймер", false)
        }
        m("""напомни(?: мне)?\s+через\s+(.+)""")?.let {
            val r = Parse.reminderIn(it.groupValues[1]) ?: return LocalResult("Не понял, когда напомнить. Скажите, например: «напомни через 15 минут про чай».")
            return timer(ctx, r.first, r.second.ifBlank { "Напоминание" }, true)
        }
        m("""напомни(?: мне)?\s+в\s+(.+)""")?.let {
            val r = Parse.reminderAt(it.groupValues[1]) ?: return LocalResult("Не понял время. Скажите, например: «напомни в 18:00 позвонить маме».")
            return alarm(ctx, r.first, r.second, r.third.ifBlank { "Напоминание" })
        }

        // ---------- время в телефоне ----------
        if ((t.startsWith("сколько") && (t.contains("в телефоне") || t.contains("с телефоном"))) || t.contains("экранное время"))
            return usage(ctx)
        m("""(?:поставь|установи) лимит (?:на )?(?:телефон|телефона|экранного времени)\s+(.+)""")?.let {
            val sec = Parse.duration(Parse.digits(it.groupValues[1])) ?: return LocalResult("Скажите, например: «поставь лимит телефона 3 часа».")
            ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE).edit().putInt("limit_min", sec / 60).apply()
            return LocalResult("Лимит ${Parse.human(sec)} в день. Я предупрежу, когда он закончится, если включено прослушивание имени.")
        }
        if (m("(?:убери|отключи|выключи) лимит(?: телефона)?") != null) {
            ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE).edit().putInt("limit_min", 0).apply()
            return LocalResult("Лимит убран.")
        }

        // ---------- автоответ в мессенджерах ----------
        if (m("включи автоответ|включи автоответчик") != null) return autoReply(ctx, true)
        if (m("выключи автоответ|отключи автоответ|выключи автоответчик") != null) return autoReply(ctx, false)
        m("""(?:поставь автоответ|текст автоответа|автоответ)\s+(.+)""")?.let {
            val text = it.groupValues[1].replaceFirstChar { c -> c.uppercase() }
            ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE).edit().putString("autotext", text).apply()
            return LocalResult("Текст автоответа: $text.")
        }
        if (m("который час|сколько времени|сколько сейчас времени|время") != null)
            return LocalResult("Сейчас " + SimpleDateFormat("HH:mm", ru).format(Date()))
        if (m("какое сегодня число|какой сегодня день|какая сегодня дата|какое число|какой день недели|какой сегодня день недели") != null)
            return LocalResult("Сегодня " + SimpleDateFormat("d MMMM, EEEE", ru).format(Date()))

        m("""открой сайт (.+)""")?.let {
            val u = it.groupValues[1].replace(" точка ", ".").replace(" ", "")
            open(ctx, if (u.startsWith("http")) u else "https://$u")
            return LocalResult("Открываю $u")
        }
        m("""(?:найди|поищи|загугли|погугли|найти|поиск)\s+(?:в\s+(интернете|гугле|google|яндексе|браузере)\s+)?(.+)""")?.let {
            val q = it.groupValues[2]
            val url = if (it.groupValues[1] == "яндексе") "https://yandex.ru/search/?text=${enc(q)}"
                      else "https://www.google.com/search?q=${enc(q)}"
            open(ctx, url)
            return LocalResult("Ищу в интернете: $q")
        }
        m("""(?:какая\s+)?погода(?:\s+(?:в|во|на))?\s*(.*)""")?.let {
            val city = it.groupValues[1].replace(Regex("\\s*(сегодня|сейчас|завтра)$"), "").trim()
            if (city.isEmpty() || city == "улице") return LocalResult("Назовите город, например: «погода в Москве».")
            return LocalResult(weather(city))
        }
        m("""(?:что такое|кто такой|кто такая|кто такие|что значит|что означает|расскажи про|расскажи о|расскажи об|википедия)\s+(.+)""")?.let {
            return answer(ctx, it.groupValues[1])
        }
        m("""(?:посчитай|сколько будет|реши|вычисли)\s+(.+)""")?.let {
            val v = calc(it.groupValues[1]) ?: return LocalResult("Не смог посчитать. Скажите, например: «посчитай 12 умножить на 7».")
            return LocalResult("Получится $v")
        }
        m("""(?:набери|позвони)\s+(?:на\s+номер\s+)?([\d\s+()-]+)""")?.let {
            val num = it.groupValues[1].replace(Regex("[\\s()-]"), "")
            open(ctx, "tel:" + Uri.encode(num), Intent.ACTION_DIAL)
            return LocalResult("Набираю $num. Нажмите кнопку вызова.")
        }
        m("""(?:набери|позвони)\s+(.+)""")?.let {
            val num = Learn.contact(ctx, it.groupValues[1])
                ?: return LocalResult("Не знаю такого номера. Скажите: «запомни номер ${it.groupValues[1]} +7…», и я запомню.")
            open(ctx, "tel:" + Uri.encode(num), Intent.ACTION_DIAL)
            return LocalResult("Набираю: ${it.groupValues[1]}. Нажмите кнопку вызова.")
        }

        if (m("назад|вернись|вернись назад") != null) return act("back")
        if (m("домой|на главный экран|главный экран|на рабочий стол") != null) return act("home")
        m("""(?:(?:прокрути|листай|пролистай|скролль)\s+)?(вниз|вверх)""")?.let { return act("scroll", "dir" to (if (it.groupValues[1] == "вниз") "down" else "up")) }
        m("""(?:нажми|кликни|тапни|жми)(?:\s+на)?\s+(.+)""")?.let { return act("click", "text" to it.groupValues[1]) }
        m("""(?:напиши|введи|впиши)\s+(.+)""")?.let { return act("type", "text" to it.groupValues[1]) }

        m("""(?:открой|открыть|запусти|запустить|включи|включить)\s+(?:приложение\s+)?(.+)""")?.let {
            val app = it.groupValues[1]
            return if (openApp(ctx, app)) LocalResult("Открываю $app") else LocalResult("Не нашёл приложение «$app».")
        }

        if (m("""(?:кто|что|где|когда|почему|зачем|как|сколько|какой|какая|какие|чем|откуда|куда)\s.+""") != null)
            return if (hasAi) LocalResult(unknown = true) else answer(ctx, t)
        if (hasAi) return LocalResult(unknown = true)
        Learn.logUnknown(ctx, t)
        return LocalResult("Такой команды я не знаю. Скажите «что ты умеешь», или научите: «когда я говорю …, делай …».")
    }


    // ---------- вспомогательные функции ----------
    private fun settings(ctx: Context, action: String) {
        try { ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
    }

    private fun alarm(ctx: Context, h: Int, m: Int, label: String): LocalResult = try {
        ctx.startActivity(Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        LocalResult("Поставил на ${"%02d:%02d".format(h, m)}: $label.")
    } catch (e: Exception) { LocalResult("Не удалось поставить: на телефоне нет приложения «Часы».") }

    private fun timer(ctx: Context, sec: Int, label: String, remind: Boolean): LocalResult = try {
        ctx.startActivity(Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, sec).putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        LocalResult(if (remind) "Напомню через ${Parse.human(sec)}: $label." else "Таймер на ${Parse.human(sec)}.")
    } catch (e: Exception) { LocalResult("Не удалось поставить таймер: на телефоне нет приложения «Часы».") }

    private fun dnd(ctx: Context, on: Boolean): LocalResult {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) {
            if (!on) return LocalResult("Доброе утро!")
            settings(ctx, Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            return LocalResult("Разрешите «Ассистенту» доступ к режиму «Не беспокоить», потом повторите.")
        }
        nm.setInterruptionFilter(if (on) NotificationManager.INTERRUPTION_FILTER_ALARMS else NotificationManager.INTERRUPTION_FILTER_ALL)
        return LocalResult(if (on) "Режим сна включён. Звонки и уведомления выключены, будильники прозвучат. Спокойной ночи!"
            else "Режим сна выключен. Доброе утро!")
    }

    fun hasUsageAccess(ctx: Context): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName) == AppOpsManager.MODE_ALLOWED
    }

    /** Пары «пакет — миллисекунды на экране сегодня», по убыванию. */
    fun usageToday(ctx: Context): List<Pair<String, Long>> {
        val um = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        val stats = um.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, cal.timeInMillis, System.currentTimeMillis()) ?: return emptyList()
        val home = ctx.packageManager.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)?.activityInfo?.packageName
        val skip = setOfNotNull(home, ctx.packageName, "com.android.systemui")
        val sum = HashMap<String, Long>()
        for (s in stats) if (s.packageName !in skip && s.totalTimeInForeground > 0)
            sum[s.packageName] = (sum[s.packageName] ?: 0L) + s.totalTimeInForeground
        return sum.entries.sortedByDescending { it.value }.map { Pair(it.key, it.value) }
    }

    private fun usage(ctx: Context): LocalResult {
        if (!hasUsageAccess(ctx)) {
            settings(ctx, Settings.ACTION_USAGE_ACCESS_SETTINGS)
            return LocalResult("Разрешите «Ассистенту» доступ к статистике использования, потом повторите вопрос.")
        }
        val list = usageToday(ctx)
        if (list.isEmpty()) return LocalResult("Пока нет данных за сегодня.")
        val pm = ctx.packageManager
        val total = (list.sumOf { it.second } / 1000L).toInt()
        val top = list.take(3).joinToString(", ") { p ->
            val label = try { pm.getApplicationLabel(pm.getApplicationInfo(p.first, 0)).toString() } catch (e: Exception) { p.first }
            "$label — ${Parse.human((p.second / 1000L).toInt())}"
        }
        val lim = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE).getInt("limit_min", 0)
        val tail = if (lim > 0 && total / 60 >= lim) " Это больше вашего лимита." else ""
        return LocalResult("Сегодня в телефоне около ${Parse.human(total)}. Больше всего: $top.$tail")
    }

    private fun autoReply(ctx: Context, on: Boolean): LocalResult {
        val sp = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        sp.edit().putBoolean("autoreply", on).apply()
        if (!on) return LocalResult("Автоответ выключен.")
        val enabled = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners")?.contains(ctx.packageName) == true
        if (!enabled) {
            settings(ctx, Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
            return LocalResult("Включите «Ассистент» в списке доступа к уведомлениям, и автоответ заработает.")
        }
        val text = sp.getString("autotext", null) ?: DEFAULT_AUTOTEXT
        return LocalResult("Автоответ включён. Текст: $text. Отвечаю в личных чатах Telegram, WhatsApp, ВКонтакте, Viber и Signal один раз за шесть часов каждому. В группах, СМС и банках молчу.")
    }

    /** Ответ на вопрос: сначала Википедия, если ничего нет, открываем поиск в браузере. */
    private fun answer(ctx: Context, q: String): LocalResult {
        wiki(q)?.let { return LocalResult(it) }
        open(ctx, "https://www.google.com/search?q=${enc(q)}")
        return LocalResult("В Википедии не нашёл, открываю поиск в интернете.")
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun open(ctx: Context, url: String, action: String = Intent.ACTION_VIEW) {
        ctx.startActivity(Intent(action, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun openApp(ctx: Context, name: String): Boolean {
        val pm = ctx.packageManager
        val apps = pm.getInstalledApplications(0)
        for (w in aliases[name] ?: listOf(name)) {
            val app = apps.firstOrNull {
                pm.getLaunchIntentForPackage(it.packageName) != null &&
                    pm.getApplicationLabel(it).toString().contains(w, true)
            } ?: continue
            ctx.startActivity(pm.getLaunchIntentForPackage(app.packageName)!!.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return true
        }
        return false
    }

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 15000
        c.setRequestProperty("User-Agent", "AssistantApp/1.1 (Android)")
        c.setRequestProperty("Accept", "application/json")
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally { c.disconnect() }
    }

    private fun wiki(topic: String): String? {
        val j = JSONObject(get("https://ru.wikipedia.org/w/api.php?action=query&generator=search" +
            "&gsrsearch=${enc(topic)}&gsrlimit=1&prop=extracts&exintro=1&explaintext=1&exsentences=3" +
            "&format=json&utf8=1&redirects=1"))
        val pages = j.optJSONObject("query")?.optJSONObject("pages") ?: return null
        val key = pages.names()?.optString(0)?.takeIf { it.isNotEmpty() } ?: return null
        val text = pages.getJSONObject(key).optString("extract").replace(Regex("\\s*\\([^)]*\\)"), "").trim()
        if (text.isBlank()) return null
        val cut = text.take(450)
        val i = cut.lastIndexOf('.')
        return if (i > 100) cut.substring(0, i + 1) else cut
    }

    private fun deg(n: Int) = when {
        n % 10 == 1 && n % 100 != 11 -> "градус"
        n % 10 in 2..4 && n % 100 !in 12..14 -> "градуса"
        else -> "градусов"
    }

    private fun sky(c: Int) = when (c) {
        0 -> "ясно"
        1 -> "малооблачно"
        2 -> "переменная облачность"
        3 -> "пасмурно"
        45, 48 -> "туман"
        in 51..57 -> "морось"
        in 61..67 -> "дождь"
        in 71..77 -> "снег"
        in 80..82 -> "ливень"
        85, 86 -> "снегопад"
        in 95..99 -> "гроза"
        else -> "облачно"
    }

    private fun weather(city: String): String {
        fun find(n: String) = JSONObject(get("https://geocoding-api.open-meteo.com/v1/search?name=${enc(n)}" +
            "&count=1&language=ru&format=json")).optJSONArray("results")
        var res = find(city)
        if ((res == null || res.length() == 0) && city.length > 3) res = find(city.dropLast(1))
        if (res == null || res.length() == 0) return "Не нашёл город «$city»."
        val g = res.getJSONObject(0)
        val w = JSONObject(get("https://api.open-meteo.com/v1/forecast?latitude=${g.getDouble("latitude")}" +
            "&longitude=${g.getDouble("longitude")}&current=temperature_2m,weather_code,wind_speed_10m" +
            "&wind_speed_unit=ms&timezone=auto")).getJSONObject("current")
        val t = Math.round(w.getDouble("temperature_2m")).toInt()
        val tp = when { t < 0 -> "минус ${-t} ${deg(-t)}"; t > 0 -> "плюс $t ${deg(t)}"; else -> "ноль градусов" }
        val wind = Math.round(w.getDouble("wind_speed_10m")).toInt()
        return "Погода, ${g.optString("name", city)}: сейчас $tp, ${sky(w.getInt("weather_code"))}, ветер $wind метров в секунду."
    }

    private fun calc(src: String): String? {
        val e = src.replace("умножить на", "*").replace("умножить", "*").replace("разделить на", "/")
            .replace("делить на", "/").replace("плюс", "+").replace("минус", "-")
            .replace(",", ".").replace(" ", "")
        if (!Regex("[0-9.+\\-*/()]+").matches(e)) return null
        return try {
            val v = Calc(e).parse()
            if (v.isNaN() || v.isInfinite()) null
            else if (v == Math.floor(v) && Math.abs(v) < 1e15) v.toLong().toString()
            else String.format(ru, "%.4f", v).trimEnd('0').trimEnd(',')
        } catch (ex: Exception) { null }
    }

    private class Calc(val s: String) {
        var p = 0
        fun parse(): Double { val v = expr(); if (p != s.length) throw IllegalArgumentException(); return v }
        fun expr(): Double {
            var v = term()
            while (p < s.length && (s[p] == '+' || s[p] == '-')) { val o = s[p++]; val r = term(); v = if (o == '+') v + r else v - r }
            return v
        }
        fun term(): Double {
            var v = factor()
            while (p < s.length && (s[p] == '*' || s[p] == '/')) { val o = s[p++]; val r = factor(); v = if (o == '*') v * r else v / r }
            return v
        }
        fun factor(): Double {
            if (p < s.length && s[p] == '-') { p++; return -factor() }
            if (p < s.length && s[p] == '(') {
                p++; val v = expr()
                if (p >= s.length || s[p] != ')') throw IllegalArgumentException()
                p++; return v
            }
            val st = p
            while (p < s.length && (s[p].isDigit() || s[p] == '.')) p++
            return s.substring(st, p).toDouble()
        }
    }
}
