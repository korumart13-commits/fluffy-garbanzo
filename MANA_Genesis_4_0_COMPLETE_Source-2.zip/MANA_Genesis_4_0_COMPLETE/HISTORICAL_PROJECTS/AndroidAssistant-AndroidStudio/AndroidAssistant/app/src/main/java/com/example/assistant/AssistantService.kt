package com.example.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONObject

class AssistantService : AccessibilityService() {
    companion object { var instance: AssistantService? = null }

    // Банковские приложения определяем по названию, а не по пакету
    private val bankWords = listOf("сбер", "альфа", "alfa", "ozon банк", "ozon bank", "озон банк")
    // Слова, на которые ассистент не имеет права нажимать в банке
    private val payWords = listOf("оплат", "перевест", "перевод", "подтверд", "отправ", "платеж", "платёж", "заплат", "готово")
    // Признаки экрана подтверждения платежа
    private val confirmScreen = listOf("подтвердите", "код из", "пин-код", "введите код", "по отпечатку")

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(i: Intent?): Boolean { instance = null; return super.onUnbind(i) }

    private fun inBank(): Boolean {
        val pkg = rootInActiveWindow?.packageName?.toString() ?: return false
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) { return false }
        return bankWords.any { label.contains(it, true) }
    }

    private fun rawText(): String {
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || n.isPassword) return
            (n.text ?: n.contentDescription)?.let { sb.append(it).append(" | ") }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(rootInActiveWindow)
        return sb.toString().take(3000)
    }

    // В банке номера и длинные числа маскируются перед отправкой в ИИ
    fun screenText(): String {
        val t = rawText()
        return if (inBank()) "[банковское приложение] " + t.replace(Regex("\\d{4,}"), "••••") else t
    }

    // Возвращает сообщение пользователю, если действие заблокировано
    fun act(a: JSONObject): String? {
        when (a.optString("type")) {
            "open_app" -> openApp(a.optString("name"))
            "click" -> {
                val t = a.optString("text")
                if (inBank()) {
                    val onConfirm = confirmScreen.any { rawText().contains(it, true) }
                    if (onConfirm || payWords.any { t.contains(it, true) })
                        return "Здесь нужно подтвердить действие вам самому: нажмите «$t» и введите код или отпечаток вручную."
                }
                click(t)
            }
            "type" -> return typeText(a.optString("text"))
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "scroll" -> scroll(a.optString("dir") == "down")
        }
        return null
    }

    private fun openApp(name: String) {
        val pm = packageManager
        val app = pm.getInstalledApplications(0).firstOrNull {
            pm.getApplicationLabel(it).toString().contains(name, true) &&
                pm.getLaunchIntentForPackage(it.packageName) != null
        } ?: return
        startActivity(pm.getLaunchIntentForPackage(app.packageName)!!
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun click(text: String) {
        val nodes = rootInActiveWindow?.findAccessibilityNodeInfosByText(text) ?: return
        for (n in nodes) {
            var x: AccessibilityNodeInfo? = n
            while (x != null) {
                if (x.isClickable) { x.performAction(AccessibilityNodeInfo.ACTION_CLICK); return }
                x = x.parent
            }
        }
    }

    private fun typeText(text: String): String? {
        val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return null
        if (f.isPassword) return "Поле для пароля или кода: введите его сами."
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
        return null
    }

    private fun scroll(down: Boolean) {
        fun find(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
            if (n == null) return null
            if (n.isScrollable) return n
            for (i in 0 until n.childCount) find(n.getChild(i))?.let { return it }
            return null
        }
        find(rootInActiveWindow)?.performAction(
            if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
    }
}
