package com.example.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Memory {
    private fun sp(c: Context) = c.getSharedPreferences("mem", Context.MODE_PRIVATE)
    fun all(c: Context): String = (sp(c).getStringSet("facts", emptySet()) ?: emptySet()).joinToString("\n")
    fun add(c: Context, fact: String) {
        val s = (sp(c).getStringSet("facts", emptySet()) ?: emptySet()).toMutableSet()
        s.add(fact); sp(c).edit().putStringSet("facts", s).apply()
    }
    fun clear(c: Context) = sp(c).edit().remove("facts").apply()
}

object Brain {
    private val history = mutableListOf<Pair<String, String>>()

    private const val SYSTEM = """Ты голосовой ассистент, управляющий Android-телефоном пользователя. Отвечай по-русски.
Верни ТОЛЬКО JSON без пояснений и markdown:
{"say":"что сказать вслух","actions":[...],"remember":["новый факт о пользователе"],"done":true}
Действия: {"type":"open_app","name":"название"}, {"type":"click","text":"текст кнопки"},
{"type":"type","text":"текст"}, {"type":"back"}, {"type":"home"}, {"type":"scroll","dir":"down|up"}.
Тебе дан текст текущего экрана. Если задача требует нескольких шагов и нужно увидеть новый экран, верни done:false, и ты получишь экран снова.
В remember добавляй только устойчивые предпочтения и факты, которые пользователь сообщил. Для обычного разговора actions пустой.
Не вводи пароли и коды. С банками (Сбербанк, Альфа-Банк, Ozon Банк) работай так: открой приложение, найди нужный экран, заполни получателя и сумму, затем остановись и скажи пользователю проверить данные и самому нажать кнопку подтверждения и ввести код или отпечаток. Сам платёж никогда не подтверждай."""

    fun ask(key: String, user: String, screen: String, memory: String, name: String): JSONObject {
        val msgs = JSONArray()
        history.takeLast(16).forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
        msgs.put(JSONObject().put("role", "user").put("content", "Экран: $screen\nКоманда: $user"))
        val body = JSONObject()
            .put("model", "claude-sonnet-5-5")
            .put("max_tokens", 1000)
            .put("system", "Тебя зовут $name. Откликайся на это имя.\n" + SYSTEM + "\nЧто ты знаешь о пользователе:\n" + memory)
            .put("messages", msgs)
        val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 30000; conn.readTimeout = 60000; conn.doOutput = true
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("x-api-key", key)
        conn.setRequestProperty("anthropic-version", "2023-06-01")
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val txt = (if (code in 200..299) conn.inputStream else conn.errorStream)
            .bufferedReader(Charsets.UTF_8).use { it.readText() }
        if (code !in 200..299) throw Exception("API $code: $txt")
        val out = JSONObject(txt).getJSONArray("content").getJSONObject(0).getString("text")
            .replace("```json", "").replace("```", "").trim()
        history.add("user" to user); history.add("assistant" to out)
        val a = out.indexOf('{'); val b = out.lastIndexOf('}')
        return try { JSONObject(if (a >= 0 && b > a) out.substring(a, b + 1) else out) }
        catch (e: Exception) { JSONObject().put("say", out).put("done", true) }
    }
}
