package com.example.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Фоновое прослушивание: ждёт имя ассистента и выполняет команду, сказанную после него. */
class ListenService : Service() {
    companion object { @Volatile var running = false }

    private val h = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var speaking = 0
    private var busy = false
    private var awakeUntil = 0L
    private var lastWarn = 0L

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == "stop") { stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("listen", "Прослушивание имени", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(this, 0,
            Intent(this, ListenService::class.java).setAction("stop"), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "listen")
            .setContentTitle("Ассистент слушает")
            .setContentText("Назовите моё имя и команду")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Выключить", stopPi)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        if (!running) { running = true; startUp() }
        return START_STICKY
    }

    private fun startUp() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { stopSelf(); return }
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("ru")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { h.post { speaking = maxOf(0, speaking - 1) } }
                    override fun onError(utteranceId: String?) { h.post { speaking = maxOf(0, speaking - 1) } }
                })
            }
        }
        listen()
        h.postDelayed(limitCheck, 60_000L)
    }

    private fun say(t: String) {
        h.post {
            speaking++
            if (tts?.speak(t, TextToSpeech.QUEUE_ADD, null, "s${System.nanoTime()}") != TextToSpeech.SUCCESS)
                speaking = maxOf(0, speaking - 1)
        }
    }

    private fun listen() {
        if (!running) return
        if (speaking > 0 || busy) { h.postDelayed({ listen() }, 600); return }
        rec?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
            override fun onError(e: Int) {
                if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { stopSelf(); return }
                h.postDelayed({ listen() }, if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500L else 400L)
            }
            override fun onResults(b: Bundle?) {
                b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { heard(it) }
                h.postDelayed({ listen() }, 400L)
            }
        })
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        })
    }

    private fun heard(text: String) {
        val ru = Locale("ru")
        val name = Cfg.name(this).lowercase(ru).trim()
        val t = text.lowercase(ru).trim()
        val now = System.currentTimeMillis()
        val i = t.indexOf(name)
        val cmd: String? = when {
            name.isNotEmpty() && i >= 0 -> t.substring(i + name.length).trim { it == ' ' || it == ',' || it == '.' }
            now < awakeUntil -> t
            else -> null
        }
        if (cmd == null) return
        if (cmd.isEmpty()) { awakeUntil = now + 8000L; say("Слушаю."); return }
        awakeUntil = 0L
        busy = true
        Thread {
            Runner.run(this@ListenService, cmd, { say(it) }, { h.post { tts?.stop(); speaking = 0 } })
            h.post { busy = false }
        }.start()
    }

    // Раз в 15 минут сверяем время в телефоне с лимитом и предупреждаем
    private val limitCheck = object : Runnable {
        override fun run() {
            try {
                val limit = getSharedPreferences("cfg", MODE_PRIVATE).getInt("limit_min", 0)
                if (limit > 0 && Local.hasUsageAccess(this@ListenService)) {
                    val totalMin = Local.usageToday(this@ListenService).sumOf { it.second } / 60000L
                    val now = System.currentTimeMillis()
                    if (totalMin >= limit && now - lastWarn > 3_600_000L) {
                        lastWarn = now
                        say("Вы уже ${Parse.human((totalMin * 60).toInt())} в телефоне. Это больше лимита. Сделайте перерыв.")
                    }
                }
            } catch (e: Exception) { }
            h.postDelayed(this, 15 * 60_000L)
        }
    }

    override fun onDestroy() {
        running = false
        h.removeCallbacksAndMessages(null)
        rec?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
