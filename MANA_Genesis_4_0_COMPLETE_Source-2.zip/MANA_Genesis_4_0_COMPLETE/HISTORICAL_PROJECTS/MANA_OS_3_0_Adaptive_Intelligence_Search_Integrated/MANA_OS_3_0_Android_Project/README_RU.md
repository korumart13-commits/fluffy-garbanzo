# MANA OS 3.0 — Android Studio Starter Project

Это модульный Android Studio проект на Kotlin, построенный вокруг MANA OS 3.0 Core.
Он не является готовой AOSP-прошивкой и не заменяет системный Android SystemUI.

## Состав

- `:app` — запускаемое приложение-панель MANA OS.
- `:core` — общие модели и логика MANA Core.
- `:launcher` — базовый HOME launcher, который показывает приложения, видимые PackageManager.
- `:settings` — экран настроек темы и поведения MANA (пока хранение только в памяти процесса).
- `:systemui` — NotificationListenerService для чтения уведомлений после явного включения доступа пользователем.

## Требования

- Android Studio с поддержкой Android Gradle Plugin 8.7.3.
- JDK 17.
- Android SDK Platform 35 и Build Tools, установленные через SDK Manager.
- Для установки приложения: Android 10+ (minSdk 29). Для разработки прошивки нужен отдельный AOSP build environment.

## Открытие и сборка

1. Распакуйте архив.
2. В Android Studio выберите **Open** и укажите папку `MANA_OS_3_0_Android_Project`.
3. Дождитесь Gradle Sync и установите недостающие SDK-компоненты, если Android Studio предложит.
4. Выберите конфигурацию `app` и запустите на устройстве или эмуляторе.
5. Для APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

Командная сборка при установленном Android SDK и Gradle:

```bash
gradle assembleDebug
```

Если Gradle Wrapper отсутствует, Android Studio может сгенерировать его через **File → New → New Project** не требуется; проще выполнить `gradle wrapper` из корня при установленном Gradle. Затем используйте `./gradlew assembleDebug`.

## Реализовано в этом проекте

- Общие Kotlin-модели MANA Core: задачи, контакты, финансы, настройки, permissions-state, compatibility report, SHA-256.
- Приложение-панель с запуском основных экранов.
- HOME activity, которую Android может предложить выбрать как домашний экран.
- Экран настроек с работающими переключателями в рамках процесса приложения.
- Notification listener, сохраняющий заголовок/текст полученных уведомлений в памяти процесса после предоставления пользователем доступа.
- Тёмно-синяя палитра и векторная эмблема MANA.

## Не реализовано и не должно считаться готовым

- Это не AOSP build, не OTA-пакет и не прошивка.
- `:systemui` — notification listener, а не замена панели состояния, шторки или системного SystemUI Android.
- MANA Permission Manager пока хранит внутреннее состояние приложения. Реальные разрешения Android выдаются/отзываются через Android PermissionController и системные API; обычное приложение не может произвольно отзывать разрешения других пакетов.
- Smart Receptionist пока содержит логику/модели. Автоприём звонков требует интеграции с Telecom, системной роли/привилегий, разрешений, проверки OEM и соблюдения законов о записи/уведомлении собеседника.
- Yandex/VK OAuth и API не подключены: нужны конкретные официальные API, OAuth redirect configuration и защищённое хранение токенов. В исходниках нет фиктивных успешных подключений.
- Нет полноценного ИИ-провайдера: `ManaAiProvider` — интерфейс для подключения локальной модели или сервиса.
- Нет OTA-установщика, Recovery, AVB signing или device-specific images.

## Следующий этап AOSP

Для настоящей MANA OS на устройстве потребуются:

1. Точный device codename, SoC, Android base branch и partition layout.
2. AOSP manifest/branch, device tree, kernel source/config, vendor blobs и HAL для конкретной модели.
3. Интеграция модулей в `Android.bp`/Soong и product makefiles (`PRODUCT_PACKAGES`).
4. Отдельная разработка/форк AOSP SystemUI, framework overlays, Settings и Launcher.
5. Привилегии — только через контролируемую системную сборку и platform signing; SELinux и Verified Boot не отключать.
6. OTA с device-specific payload, AVB metadata, release signing, rollback protection и проверками целостности.
7. Тестирование на отдельном устройстве с резервной копией и способом восстановления.

**Важно:** не прошивайте этот Android Studio APK/проект как системный образ. Он предназначен для разработки и тестирования приложения MANA.

## MANA Adaptive Intelligence

В приложение добавлен экран `MANA Adaptive Intelligence · отчёты`: здесь можно сохранить ключ Brave Search API (шифрование Android Keystore), запустить цикл обучения, просматривать отчёты и приостанавливать фоновую работу. Подробная настройка и ограничения описаны в `ADAPTIVE_INTELLIGENCE_SETUP_RU.md`.
