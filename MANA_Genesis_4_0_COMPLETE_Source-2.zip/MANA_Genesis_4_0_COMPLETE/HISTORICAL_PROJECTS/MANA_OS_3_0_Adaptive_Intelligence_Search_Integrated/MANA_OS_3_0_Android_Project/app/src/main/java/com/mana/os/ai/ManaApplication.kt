package com.mana.os.ai

import android.app.Application

class ManaApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // WorkManager persists unique periodic work across process death and device reboot.
        ManaLearningScheduler.register(this)
    }
}
