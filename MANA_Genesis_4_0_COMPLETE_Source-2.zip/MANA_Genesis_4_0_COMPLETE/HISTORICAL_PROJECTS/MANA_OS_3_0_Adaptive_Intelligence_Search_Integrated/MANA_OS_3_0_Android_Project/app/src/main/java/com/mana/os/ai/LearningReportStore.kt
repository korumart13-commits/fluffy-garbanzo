package com.mana.os.ai

import android.content.Context
import com.mana.os.core.ai.LearningCycleReport
import com.mana.os.core.ai.LearningState
import org.json.JSONArray
import org.json.JSONObject

class LearningReportStore(context: Context) {
    private val prefs = context.getSharedPreferences("mana_ai_reports", Context.MODE_PRIVATE)
    @Synchronized fun save(report: LearningCycleReport, note: String = "") {
        val row = JSONObject().apply {
            put("started", report.startedAt); put("finished", report.finishedAt)
            put("topics", report.topicsVisited); put("fetched", report.documentsFetched)
            put("bytes", report.bytesDownloaded); put("accepted", report.accepted)
            put("rejected", report.rejected); put("pending", report.needsCorroboration)
            put("state", report.state.name); put("note", note)
            put("highlights", JSONArray(report.highlights))
        }
        val old = JSONArray(prefs.getString("items", "[]"))
        val next = JSONArray().put(row)
        for (i in 0 until minOf(old.length(), 49)) next.put(old.getJSONObject(i))
        prefs.edit().putString("items", next.toString()).apply()
    }
    fun recent(): List<JSONObject> {
        val array = JSONArray(prefs.getString("items", "[]"))
        return (0 until array.length()).mapNotNull { array.optJSONObject(it) }
    }
    fun latestText(): String {
        val rows = recent()
        if (rows.isEmpty()) return "Отчётов пока нет. Настрой API-ключ и запусти обучение."
        return rows.joinToString("\n\n────────────────────\n\n") { r ->
            val highlights = r.optJSONArray("highlights")
            val lines = (0 until (highlights?.length() ?: 0)).joinToString("\n") { "• ${highlights?.optString(it)}" }
            "${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(r.optLong("started")))}\n" +
                "Статус: ${r.optString("state")}\nТем: ${r.optInt("topics")} · найдено: ${r.optInt("fetched")}\n" +
                "В базе: ${r.optInt("accepted")} · отклонено: ${r.optInt("rejected")} · ожидают проверки: ${r.optInt("pending")}\n" +
                "Трафик: ${r.optLong("bytes") / 1024} КБ\n${r.optString("note")}\n$lines"
        }
    }
}
