package com.mana.os.ai

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

object ManaLearningScheduler {
    private const val UNIQUE_NAME = "mana-adaptive-learning"
    private fun constraints() = Constraints.Builder()
        .setRequiredNetworkType(NetworkType.UNMETERED)
        .setRequiresBatteryNotLow(true)
        .setRequiresCharging(true)
        .build()

    fun register(context: Context) {
        val request = PeriodicWorkRequestBuilder<ManaLearningWorker>(6, TimeUnit.HOURS)
            .setConstraints(constraints())
            .addTag("mana-adaptive-intelligence")
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            UNIQUE_NAME, ExistingPeriodicWorkPolicy.KEEP, request)
    }
    fun runNow(context: Context) {
        val request = androidx.work.OneTimeWorkRequestBuilder<ManaLearningWorker>()
            .setConstraints(constraints())
            .addTag("mana-adaptive-intelligence-manual").build()
        WorkManager.getInstance(context).enqueue(request)
    }
    fun cancel(context: Context) = WorkManager.getInstance(context).cancelUniqueWork(UNIQUE_NAME)
}
