package com.mana.os.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.mana.os.core.MANA
import com.mana.os.core.ManaSystem
import com.mana.os.launcher.ManaLauncherActivity
import com.mana.os.settings.ManaSettingsActivity
import com.mana.os.ai.ManaAiReportsActivity

class MainActivity : Activity() {
    private val mana = ManaSystem()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 48, 24, 24)
            setBackgroundColor(android.graphics.Color.parseColor(MANA.Colors.BACKGROUND))
        }
        root.addView(TextView(this).apply {
            text = "MANA"
            textSize = 42f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.parseColor(MANA.Colors.ACCENT))
        }, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(TextView(this).apply {
            text = "OS ${MANA.VERSION}  •  ${MANA.CODENAME}"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.parseColor(MANA.Colors.SECONDARY))
        })
        root.addView(TextView(this).apply {
            text = "Ядро MANA инициализировано.\nМодулей: ${MANA.modules.size}\nОбязательные GMS: нет"
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 28)
            setTextColor(android.graphics.Color.parseColor(MANA.Colors.TEXT))
        })
        addButton(root, "Открыть рабочий стол") {
            startActivity(Intent(this, ManaLauncherActivity::class.java))
        }
        addButton(root, "MANA Adaptive Intelligence · отчёты") {
            startActivity(Intent(this, ManaAiReportsActivity::class.java))
        }
        addButton(root, "Настройки MANA") {
            startActivity(Intent(this, ManaSettingsActivity::class.java))
        }
        addButton(root, "Доступ к уведомлениям") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        addButton(root, "Проверить состояние ядра") {
            android.app.AlertDialog.Builder(this)
                .setTitle("MANA Core")
                .setMessage(mana.boot())
                .setPositiveButton("OK", null)
                .show()
        }
        setContentView(root)
    }

    private fun addButton(root: LinearLayout, label: String, action: () -> Unit) {
        root.addView(Button(this).apply {
            text = label
            setOnClickListener { action() }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = 10
        })
    }
}
