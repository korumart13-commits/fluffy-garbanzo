package com.mana.os.core.ai

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object LearningReportFormatter {
    fun format(report: LearningCycleReport, totalKnowledge: Int): String {
        val date = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ROOT)
        return buildString {
            appendLine("MANA ADAPTIVE INTELLIGENCE — ОТЧЁТ ОБ ОБУЧЕНИИ")
            appendLine("Начало: ${date.format(Date(report.startedAt))}")
            appendLine("Окончание: ${date.format(Date(report.finishedAt))}")
            appendLine("Состояние: ${report.state}")
            appendLine("Тем изучено: ${report.topicsVisited}")
            appendLine("Документов загружено: ${report.documentsFetched}")
            appendLine("Получено данных: ${report.bytesDownloaded} байт")
            appendLine("Записей принято: ${report.accepted}")
            appendLine("Отклонено: ${report.rejected}")
            appendLine("Ожидают подтверждения: ${report.needsCorroboration}")
            appendLine("Всего записей в базе знаний: $totalKnowledge")
            appendLine()
            appendLine("НОВЫЕ МАТЕРИАЛЫ / ЗАМЕТКИ")
            if (report.highlights.isEmpty()) appendLine("Новых подтверждённых материалов нет.")
            else report.highlights.forEach { appendLine("• $it") }
            appendLine()
            appendLine("Примечание: отчёт отражает обработанные источники, а не гарантирует абсолютную истинность каждого утверждения.")
        }
    }
}
