package com.mana.os.core.ai

import java.net.URI
import java.net.URL
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import javax.net.ssl.HttpsURLConnection

interface WebSearchProvider { fun search(query: String, limit: Int): List<SearchHit> }
interface DocumentFetcher { fun fetch(url: String, maxChars: Int, maxBytes: Long = 256_000L): FetchedDocument }
interface EvidenceEvaluator { fun evaluate(document: FetchedDocument, tags: Set<String>): EvidenceResult }

/** Exact host/subdomain allowlist. HTTPS only; no credentials, IP literals, or non-standard ports. */
class DomainAllowlist(private val domains: Set<String>) {
    fun sourceGroup(rawUrl: String): String? {
        return try {
            val host = URI(rawUrl).host?.lowercase() ?: return null
            domains.filter { host == it || host.endsWith(".$it") }.maxByOrNull { it.length }
        } catch (_: Exception) { null }
    }

    fun allows(rawUrl: String): Boolean {
        return try {
            val uri = URI(rawUrl).normalize()
            val host = uri.host?.lowercase() ?: return false
            uri.scheme.equals("https", true) && uri.userInfo == null &&
                (uri.port == -1 || uri.port == 443) && !host.matches(Regex("^[0-9.]+$")) &&
                domains.any { host == it || host.endsWith(".$it") }
        } catch (_: Exception) { false }
    }
}

/** Small, bounded HTTPS fetcher. Redirects are followed only when the destination remains allowlisted. */
class SafeHttpsDocumentFetcher(private val allowlist: DomainAllowlist, private val timeoutMs: Int = 8_000) : DocumentFetcher {
    override fun fetch(url: String, maxChars: Int, maxBytes: Long): FetchedDocument {
        require(maxChars in 256..100_000 && maxBytes in 1_024L..2_000_000L) { "Invalid content limit" }
        var current = url
        repeat(4) { hop ->
            require(allowlist.allows(current)) { "URL is outside the approved HTTPS source list" }
            val connection = (URI(current).toURL().openConnection() as HttpsURLConnection).apply {
                connectTimeout = timeoutMs; readTimeout = timeoutMs
                instanceFollowRedirects = false
                setRequestProperty("Accept", "text/html,text/plain,application/json;q=0.9")
                setRequestProperty("User-Agent", "MANA-OS-AdaptiveIntelligence/1.0")
            }
            try {
                val code = connection.responseCode
                if (code in 300..399) {
                    require(hop < 3) { "Too many redirects" }
                    current = connection.getHeaderField("Location")?.let { URI(current).resolve(it).toString() }
                        ?: error("Redirect without Location")
                    require(allowlist.allows(current)) { "Redirect left approved source list" }
                } else {
                    require(code in 200..299) { "HTTP status $code" }
                    val type = connection.contentType.orEmpty().lowercase()
                    require(type.startsWith("text/") || type.contains("json")) { "Unsupported content type: $type" }
                    val bytes = ByteArrayOutputStream()
                    connection.inputStream.use { input ->
                        val buffer = ByteArray(8 * 1024)
                        while (bytes.size().toLong() < maxBytes) {
                            val n = input.read(buffer, 0, minOf(buffer.size.toLong(), maxBytes - bytes.size()).toInt())
                            if (n < 0) break
                            bytes.write(buffer, 0, n)
                        }
                    }
                    val rawText = bytes.toByteArray().toString(Charsets.UTF_8)
                    val plain = rawText.replace(Regex("(?is)<(script|style)[^>]*>.*?</\\1>"), " ")
                        .replace(Regex("(?s)<[^>]+>"), " ")
                        .replace(Regex("&nbsp;|&#160;", RegexOption.IGNORE_CASE), " ")
                        .replace(Regex("\\s+"), " ").trim().take(maxChars)
                    return FetchedDocument(plain.take(180).ifBlank { current }, current, plain, bytesRead = bytes.size().toLong())
                }
            } finally { connection.disconnect() }
        }
        error("Redirect handling failed")
    }
}

/** Conservative baseline: official docs/standards rank higher; unknown sites never auto-enter the KB. */
class ConservativeEvidenceEvaluator(
    private val officialDomains: Set<String>,
    private val academicDomains: Set<String>,
    private val standardsDomains: Set<String>
) : EvidenceEvaluator {
    override fun evaluate(document: FetchedDocument, tags: Set<String>): EvidenceResult {
        val host = try { URI(document.url).host?.lowercase().orEmpty() } catch (_: Exception) { "" }
        val trust = when {
            officialDomains.any { host == it || host.endsWith(".$it") } -> SourceTrust.OFFICIAL
            standardsDomains.any { host == it || host.endsWith(".$it") } -> SourceTrust.STANDARDS_BODY
            academicDomains.any { host == it || host.endsWith(".$it") } -> SourceTrust.ACADEMIC
            else -> SourceTrust.UNKNOWN
        }
        val notes = mutableListOf<String>()
        if (document.text.length < 300) notes += "Слишком мало содержимого для оценки"
        if (Regex("(?i)ignore (all )?previous instructions|reveal.*secret|run this command").containsMatchIn(document.text))
            notes += "Обнаружен текст, похожий на внедрение инструкций; он рассматривается только как данные"
        val score = when (trust) {
            SourceTrust.OFFICIAL, SourceTrust.STANDARDS_BODY -> 85
            SourceTrust.ACADEMIC -> 75
            SourceTrust.COMMUNITY -> 45
            SourceTrust.UNKNOWN -> 15
        } + if (document.text.length >= 300) 10 else 0
        val status = when {
            trust == SourceTrust.UNKNOWN || document.text.length < 300 -> EvidenceStatus.NEEDS_CORROBORATION
            score >= 80 -> EvidenceStatus.ACCEPTED
            else -> EvidenceStatus.NEEDS_CORROBORATION
        }
        return EvidenceResult(status, trust, score.coerceAtMost(100), notes)
    }
}

internal fun sha256Hex(value: String): String = MessageDigest.getInstance("SHA-256")
    .digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
