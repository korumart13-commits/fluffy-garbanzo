package com.mana.installer

import android.app.Activity
import android.os.Build
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var reportView: TextView
    private var latestReport: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        renderHome()
        runDiagnostics()
    }

    private fun renderHome() {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(7, 20, 38)) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(22), dp(28), dp(22), dp(28))
        }
        val logo = TextView(this).apply {
            text = "MANA"
            textSize = 38f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(84, 200, 245))
        }
        root.addView(logo, matchWrap())
        root.addView(label("MOBILE INSTALLER  •  VERSION 1.0.0", 12f, "#91A9C5"))
        root.addView(label("Диагностика устройства и подготовка к установке MANA OS. Приложение ничего не прошивает и не изменяет системные разделы.", 15f, "#EAF4FF"))

        root.addView(section("ОБНАРУЖЕННОЕ УСТРОЙСТВО"))
        reportView = label("Выполняется диагностика…", 13f, "#EAF4FF")
        reportView.setBackgroundColor(Color.rgb(16, 43, 80))
        reportView.setPadding(dp(14), dp(14), dp(14), dp(14))
        root.addView(reportView, matchWrap())

        root.addView(section("ДЕЙСТВИЯ"))
        root.addView(actionButton("Проверить устройство") { runDiagnostics() })
        root.addView(actionButton("Сохранить отчёт в Файлы") { saveReport() })
        root.addView(actionButton("Подготовить план установки") { showInstallReadiness() })
        root.addView(label("Безопасность: без root, без записи разделов, без разблокировки загрузчика, без отключения AVB или SELinux. Для прошивки потребуется отдельный проверенный пакет именно для этого устройства.", 12f, "#91A9C5"))
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun runDiagnostics() {
        val model = Build.MODEL.orEmpty()
        val manufacturer = Build.MANUFACTURER.orEmpty()
        val device = Build.DEVICE.orEmpty()
        val product = Build.PRODUCT.orEmpty()
        val brand = Build.BRAND.orEmpty()
        val sdk = Build.VERSION.SDK_INT
        val release = Build.VERSION.RELEASE.orEmpty()
        val securityPatch = if (Build.VERSION.SDK_INT >= 23) Build.VERSION.SECURITY_PATCH.orEmpty() else "неизвестно"
        val abis = Build.SUPPORTED_ABIS.joinToString(", ")
        val isTargetModel = model.equals("RMX5566", ignoreCase = true) ||
            Build.MODEL.contains("RMX5566", ignoreCase = true)
        val targetCheck = if (isTargetModel) "Модель совпадает с целевой RMX5566" else "Модель не подтверждена как RMX5566"
        val codenameStatus = if (device.isNotBlank()) device else "не определён"

        latestReport = buildString {
            appendLine("MANA MOBILE INSTALLER — DEVICE REPORT")
            appendLine("Дата: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())}")
            appendLine()
            appendLine("Производитель: $manufacturer")
            appendLine("Бренд: $brand")
            appendLine("Модель: $model")
            appendLine("DEVICE codename: $codenameStatus")
            appendLine("PRODUCT: $product")
            appendLine("Android: $release (API $sdk)")
            appendLine("Security patch: $securityPatch")
            appendLine("Поддерживаемые ABI: $abis")
            appendLine()
            appendLine("Проверка целевой модели: $targetCheck")
            appendLine("Статус совместимости: НЕ ПОДТВЕРЖДЁН")
            appendLine("Причина: не проверены точная заводская прошивка, vendor/VINTF, kernel, HAL, разметка разделов, AVB и device tree.")
            appendLine()
            appendLine("РЕКОМЕНДАЦИЯ")
            appendLine("Не устанавливать и не прошивать неподтверждённые образы. Сначала сопоставить этот отчёт с официальной прошивкой и исходниками именно для данной ревизии устройства.")
            appendLine()
            appendLine("Ограничения: приложение не читает серийный номер, IMEI, контакты или личные данные; не использует root и не меняет системные файлы.")
        }
        reportView.text = latestReport
    }

    private fun showInstallReadiness() {
        val message = "Подготовка установки остановлена на безопасном этапе.\n\n" +
            "Сначала нужно подтвердить codename, Android build, vendor fingerprint, VINTF, kernel source, HAL, partition layout и AVB для этой ревизии.\n\n" +
            "Пока эти сведения не проверены, приложение не предлагает прошивку и не меняет устройство. Сохраните отчёт и передайте его для подготовки device-specific сборки."
        android.app.AlertDialog.Builder(this)
            .setTitle("MANA OS — проверка готовности")
            .setMessage(message)
            .setPositiveButton("Понятно", null)
            .show()
    }

    private fun saveReport() {
        if (latestReport.isBlank()) runDiagnostics()
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/plain"
            putExtra(Intent.EXTRA_TITLE, "MANA_device_info.txt")
        }
        startActivityForResult(intent, REQUEST_SAVE)
    }

    @Deprecated("Using activity result for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_SAVE && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(latestReport) }
                android.app.AlertDialog.Builder(this).setMessage("Отчёт сохранён.").setPositiveButton("OK", null).show()
            } catch (e: Exception) {
                android.app.AlertDialog.Builder(this).setMessage("Не удалось сохранить отчёт: ${e.message}").setPositiveButton("OK", null).show()
            }
        }
    }

    private fun section(text: String) = label(text, 12f, "#54C8F5").apply {
        setPadding(0, dp(22), 0, dp(8))
    }

    private fun label(text: String, size: Float, color: String) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(Color.parseColor(color))
        setPadding(0, dp(8), 0, dp(8))
    }

    private fun actionButton(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(23, 101, 168))
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(8) }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    companion object { private const val REQUEST_SAVE = 7041 }
}
